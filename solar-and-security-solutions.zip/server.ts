/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { Product, Order, QuotationRequest, AnalyticsSummary } from './src/types';
import { INITIAL_PRODUCTS } from './src/data/initialProducts';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Setup JSON body parsing
app.use(express.json());

// In-Memory Database State
let dbProducts: Product[] = [...INITIAL_PRODUCTS];
let dbOrders: Order[] = [
  {
    id: "ord-8831",
    customerName: "Jane Doe",
    customerEmail: "jane@company.com",
    customerPhone: "+1 (555) 321-9876",
    address: "742 Evergreen Terrace, Springfield",
    items: [
      { productId: "sol-mono-550w", productName: "Aura 550W Mono-PERC Bifacial Solar Panel", price: 249, quantity: 4 },
      { productId: "sol-inv-hybrid-8kw", productName: "Sunsynk 8kW Single-Phase Hybrid Smart Inverter", price: 1899, quantity: 1 }
    ],
    totalPrice: 2895,
    paymentMethod: "bank_transfer",
    status: "processing",
    createdAt: new Date(Date.now() - 48 * 3600 * 1000).toISOString()
  },
  {
    id: "ord-1249",
    customerName: "Richard Miller",
    customerEmail: "richard@securecorp.net",
    customerPhone: "+1 (555) 789-0123",
    address: "55 Wall Street, Suite 400, New York",
    items: [
      { productId: "sec-cam-4k-dome", productName: "SecuriEye 4K AcuSense Dome IP Security Camera", price: 149, quantity: 6 },
      { productId: "sec-ctrl-mppt-100", productName: "Victron SmartSolar MPPT 150/70 Auto-Charger", price: 389, quantity: 2 }
    ],
    totalPrice: 1672,
    paymentMethod: "delivery_payment",
    status: "pending",
    createdAt: new Date(Date.now() - 6 * 3600 * 1000).toISOString()
  }
];

let dbQuotations: QuotationRequest[] = [
  {
    id: "qte-5591",
    customer: {
      name: "Marcus Aurelius",
      email: "marcus@rome.org",
      phone: "+39 06 123456",
      buildingType: "commercial",
      roomsOrOffices: "15 rooms",
      backupHours: 8,
      securityArea: "Parking and main lobby entrance",
      preferredBrand: "Aura Solar & SecuriEye",
      budgetRange: "$3,000 - $6,000",
      notes: "Need 24-hour video logs backup for office compliance."
    },
    status: "reviewed",
    createdAt: new Date(Date.now() - 24 * 3600 * 1000).toISOString(),
    recommendations: {
      solarSystem: "Commercial Hybrid System",
      cctvSystem: "Enterprise CCTV Coverage",
      estimatedCost: 4850,
      recommendedProducts: ["sol-mono-550w", "sol-inv-hybrid-8kw", "sec-cam-4k-dome"],
      aiAnalysis: "Based on your 15-room office requirement and 8-hour desired backup, we recommend a medium scale commercial array. 8x 550W panels with a hybrid Sunsynk inverter will meet compliance needs easily."
    }
  }
];

// Initialize Gemini API client lazily to avoid startup crashes if key is omitted
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== 'MY_GEMINI_API_KEY') {
      aiClient = new GoogleGenAI({
        apiKey: key,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return aiClient;
}

// REST Endpoints

// 1. Get all products (supports keyword search, filtering)
app.get('/api/products', (req, res) => {
  const { category, subCategory, brand, limit } = req.query;
  let filtered = [...dbProducts];

  if (category) {
    filtered = filtered.filter(p => p.category === category);
  }
  if (subCategory) {
    filtered = filtered.filter(p => p.subCategory === subCategory);
  }
  if (brand) {
    filtered = filtered.filter(p => p.brand.toLowerCase() === (brand as string).toLowerCase());
  }

  if (limit) {
    const numLimit = parseInt(limit as string, 10);
    if (!isNaN(numLimit)) {
      filtered = filtered.slice(0, numLimit);
    }
  }

  res.json(filtered);
});

// 2. Add product (Admin)
app.post('/api/products', (req, res) => {
  const newProduct: Product = {
    id: `prod-${Date.now()}`,
    reviews: [],
    rating: 5.0,
    ...req.body
  };

  dbProducts.unshift(newProduct);
  res.status(201).json(newProduct);
});

// 3. Edit product (Admin)
app.put('/api/products/:id', (req, res) => {
  const { id } = req.params;
  const index = dbProducts.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }

  dbProducts[index] = { ...dbProducts[index], ...req.body };
  res.json(dbProducts[index]);
});

// 4. Delete product (Admin)
app.delete('/api/products/:id', (req, res) => {
  const { id } = req.params;
  const index = dbProducts.findIndex(p => p.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }

  dbProducts.splice(index, 1);
  res.json({ success: true, message: "Product deleted successfully" });
});

// 5. Get all orders (Admin)
app.get('/api/orders', (req, res) => {
  res.json(dbOrders);
});

// 6. Submit Order (Client)
app.post('/api/orders', (req, res) => {
  const { customerName, customerEmail, customerPhone, address, items, paymentMethod } = req.body;

  if (!customerName || !customerPhone || !items || items.length === 0) {
    return res.status(400).json({ error: "Required order details are missing." });
  }

  // Deduct stock and compute total
  let total = 0;
  const orderItems = [];

  for (const item of items) {
    const product = dbProducts.find(p => p.id === item.productId);
    if (!product) {
      return res.status(400).json({ error: `Product with ID ${item.productId} specified in order does not exist.` });
    }

    if (product.stock < item.quantity) {
      return res.status(400).json({ error: `Insufficient stock for product ${product.name}. Dynamic stock is ${product.stock}.` });
    }

    product.stock -= item.quantity;
    total += product.price * item.quantity;
    orderItems.push({
      productId: product.id,
      productName: product.name,
      price: product.price,
      quantity: item.quantity
    });
  }

  const newOrder: Order = {
    id: `ord-${Math.floor(1000 + Math.random() * 9000)}`,
    customerName,
    customerEmail: customerEmail || 'no-email@order.com',
    customerPhone,
    address: address || 'WhatsApp Checkout Direct Delivery',
    items: orderItems,
    totalPrice: total,
    paymentMethod,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  dbOrders.unshift(newOrder);
  res.status(201).json(newOrder);
});

// Change Order Status
app.put('/api/orders/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const order = dbOrders.find(o => o.id === id);

  if (!order) {
    return res.status(404).json({ error: "Order not found" });
  }

  order.status = status;
  res.json(order);
});

// 7. Get custom-spec quotes
app.get('/api/quotations', (req, res) => {
  res.json(dbQuotations);
});

// 8. Create Custom Spec Request & Generate Advice (supports Gemini optionally)
app.post('/api/quotations', async (req, res) => {
  const { customer } = req.body;

  if (!customer || !customer.name || !customer.phone) {
    return res.status(400).json({ error: "Missing customer contact details." });
  }

  // Smart Heuristic Config Matching (runs locally by default)
  const backupHr = Number(customer.backupHours) || 4;
  const roomsVal = parseInt(customer.roomsOrOffices, 10) || 3;
  
  let suggestedSolarSystem = "Essential Solar Backup Backplate";
  let suggestedCctvSystem = "Essential Dome Coverage";
  let estimated = 1500;
  let recommendedIds = ["sol-bat-lifepo4-5kwh", "sec-cam-4k-dome"];

  if (backupHr > 6 || roomsVal > 8) {
    suggestedSolarSystem = "Pro Premium Hybrid Power Plant";
    suggestedCctvSystem = "Pro Multi-Cam High Resolution Surveillance array";
    estimated = 4500;
    recommendedIds = ["sol-mono-550w", "sol-inv-hybrid-8kw", "sol-bat-lifepo4-5kwh", "sec-cam-4k-dome", "sec-nvr-8ch-poe"];
  }

  let aiAdvice = `We suggest mounting ${backupHr > 6 ? '8x high capacity bifacial solar panels paired with deep cycle batteries' : 'a local 5.12kWh lithium storage unit with 4x panels'} to safeguard your premises. Dynamic backup duration is roughly ${backupHr} hours depending on heavy appliances.`;

  const ai = getAiClient();
  if (ai) {
    try {
      const prompt = `
        A user has requested custom security & solar configuration feedback.
        Client Details:
        - Building Type: ${customer.buildingType}
        - Rooms/Offices quantity context: ${customer.roomsOrOffices}
        - Desired Backup Hours: ${backupHr}
        - CCTV Surveillance coverage area requested: ${customer.securityArea}
        - Preferred Brands: ${customer.preferredBrand}
        - Target Budget Context: ${customer.budgetRange}
        - Extra notes: ${customer.notes || 'None'}

        We have two core categories of products: Solar (panels, lithium batteries, smart inverters) and CCTV (cameras, PoE NVR arrays, cellular sim cameras).
        Analyze their request and return a polite, technical recommendation assessment under 150 words. Focus on specific component pairings.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt
      });

      if (response && response.text) {
        aiAdvice = response.text;
      }
    } catch {
      // Keep local defaults if key is dead / rate limited
    }
  }

  const newQuote: QuotationRequest = {
    id: `qte-${Math.floor(1000 + Math.random() * 9000)}`,
    customer,
    status: 'pending',
    createdAt: new Date().toISOString(),
    recommendations: {
      solarSystem: suggestedSolarSystem,
      cctvSystem: suggestedCctvSystem,
      estimatedCost: estimated,
      recommendedProducts: recommendedIds,
      aiAnalysis: aiAdvice
    }
  };

  dbQuotations.unshift(newQuote);
  res.status(201).json(newQuote);
});

// Update Quotation Status
app.put('/api/quotations/:id/status', (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const quote = dbQuotations.find(q => q.id === id);

  if (!quote) {
    return res.status(404).json({ error: "Quotation request not found" });
  }

  quote.status = status;
  res.json(quote);
});

// 9. AI Client advisory product assistant (Gemini API server side)
app.post('/api/recommend', async (req, res) => {
  const { cartItems, question } = req.body;

  let aiReply = "To get personal tech advisory advice on system setups, try configuring a Gemini API key. Meanwhile, we highly recommend integrating one of our pre-packaged lithium storages paired with 550W bifacial high efficiency panels.";

  const ai = getAiClient();
  if (ai) {
    try {
      const cartContext = cartItems && cartItems.length > 0
        ? `Current items in user's cart: ${cartItems.map((c: any) => `${c.product.name} (qty ${c.quantity})`).join(', ')}`
        : 'The user cart is currently empty.';

      const prompt = `
        You are an expert Solar Energy engineer and CCTV Surveillance security professional advisor.
        Your job is to answer prospective client queries beautifully, providing solid technical setups.
        ${cartContext}
        User Query: "${question}"
        Please provide a professional, encouraging advisory response under 120 words focusing on real solar/security products. Keep it positive and practical.
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt
      });

      if (response && response.text) {
        aiReply = response.text;
      }
    } catch (e: any) {
      aiReply = `Advisory service is parsing recommendations. (Heuristics report: Consider pairing 5.12kWh lifepo4 storage backing our 550W high-efficiency Mono panels)`;
    }
  }

  res.json({ recommendation: aiReply });
});

// 10. Dashboard Analytics computation
app.get('/api/analytics', (req, res) => {
  const revenue = dbOrders
    .filter(o => o.status !== 'pending')
    .reduce((acc, o) => acc + o.totalPrice, 0);

  const solarOrders = dbOrders.filter(o => o.items.some(i => i.productId.startsWith('sol-')));

  const summary: AnalyticsSummary = {
    revenue: revenue || 3450,
    completedSolarProjects: 14 + solarOrders.length,
    powerInstalledKw: 48.5,
    happyClients: 89 + dbOrders.length,
    pendingQuotes: dbQuotations.filter(q => q.status === 'pending').length,
    totalOrdersCount: dbOrders.length,
    productsLowStock: dbProducts.filter(p => p.stock < 15).length,
    recentOrders: dbOrders.slice(0, 5)
  };

  res.json(summary);
});

// Server Static Frontend Assembly

async function startServer() {
  // Vite Integration in Development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production path serving static compiled index
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res, next) => {
      // Ignore API triggers to let them fail with 404 instead of serving HTML
      if (req.path.startsWith('/api/')) return next();
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Solar & CCTV Solutions server running on http://localhost:${PORT}`);
  });
}

startServer();
