/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  category: 'solar' | 'cctv';
  subCategory: string; // panels, inverters, batteries, charge_controllers, cameras, dvrs, accessories, etc.
  brand: string;
  price: number;
  imageUrl: string;
  specs: Record<string, string>;
  description: string;
  installationDetails: string;
  warranty: string;
  stock: number;
  rating: number;
  reviews: Review[];
  featured?: boolean;
}

export interface Review {
  id: string;
  user: string;
  rating: number;
  comment: string;
  date: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ApplianceInput {
  id: string;
  name: string;
  quantity: number;
  wattage: number;
  hoursPerDay: number;
}

export interface CalculatorResult {
  dailyWh: number;
  recommendedInverterW: number;
  recommendedBatteryWh: number;
  recommendedBatteryAh: number;
  recommendedPanelsNum: number;
  recommendedPanelsW: number;
  backupHours: number;
  estimatedCost: number;
}

export interface CustomerDetails {
  name: string;
  email: string;
  phone: string;
  buildingType: string;
  roomsOrOffices: string;
  backupHours: number;
  securityArea: string;
  preferredBrand: string;
  budgetRange: string;
  notes?: string;
}

export interface QuotationRequest {
  id: string;
  customer: CustomerDetails;
  status: 'pending' | 'reviewed' | 'completed';
  recommendations?: {
    solarSystem?: string;
    cctvSystem?: string;
    estimatedCost: number;
    recommendedProducts: string[];
    aiAnalysis?: string;
  };
  createdAt: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  address: string;
  items: {
    productId: string;
    productName: string;
    price: number;
    quantity: number;
  }[];
  totalPrice: number;
  paymentMethod: 'bank_transfer' | 'delivery_payment' | 'whatsapp_order';
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  createdAt: string;
  invoiceUrl?: string;
}

export interface AnalyticsSummary {
  revenue: number;
  completedSolarProjects: number;
  powerInstalledKw: number;
  happyClients: number;
  pendingQuotes: number;
  totalOrdersCount: number;
  productsLowStock: number;
  recentOrders: Order[];
}
