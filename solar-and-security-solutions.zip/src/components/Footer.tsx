/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Mail, Phone, MapPin, ExternalLink } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 px-8 border-t border-slate-800 shrink-0 text-sm" id="global-footer">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <div className="w-4 h-4 bg-sky-400 rounded-full shadow-[0_0_8px_rgba(56,189,248,0.6)]"></div>
            </div>
            <span className="text-xl font-bold tracking-tight text-white">HELIOS<span className="text-blue-500 font-sans">GUARD</span></span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            Premium corporate solar energy integration and intelligent physical CCTV security coverage. Powering operations off-grid and shielding core facilities worldwide.
          </p>
        </div>

        <div>
          <h4 className="text-white text-xs font-bold tracking-widest uppercase mb-4">Solar Division</h4>
          <ul className="space-y-2 text-xs">
            <li><span className="hover:text-blue-400 transition cursor-pointer">Bifacial Panels</span></li>
            <li><span className="hover:text-blue-400 transition cursor-pointer">Smart Inverters</span></li>
            <li><span className="hover:text-blue-400 transition cursor-pointer">LiFePO4 Storage arrays</span></li>
            <li><span className="hover:text-blue-400 transition cursor-pointer">Solar Grid-Tying systems</span></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white text-xs font-bold tracking-widest uppercase mb-4">Security Division</h4>
          <ul className="space-y-2 text-xs">
            <li><span className="hover:text-blue-400 transition cursor-pointer">4K Dome Cam Intelligence</span></li>
            <li><span className="hover:text-blue-400 transition cursor-pointer">4G PTZ Cellular Cameras</span></li>
            <li><span className="hover:text-blue-400 transition cursor-pointer">PoE NVR Surveillance</span></li>
            <li><span className="hover:text-blue-400 transition cursor-pointer">Custom AI Threat Detection</span></li>
          </ul>
        </div>

        <div>
          <h4 className="text-white text-xs font-bold tracking-widest uppercase mb-4">Global HQ Contact</h4>
          <div className="space-y-3 text-xs">
            <div className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-blue-500" /> <span>1-800-HELIOS (435-467)</span></div>
            <div className="flex items-center gap-2"><Mail className="w-3.5 h-3.5 text-blue-500" /> <span>contact@heliosguard-tech.com</span></div>
            <div className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-blue-500" /> <span>Vanguard Energy Tower, Central Park, NY</span></div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-medium text-slate-500">
        <div className="flex gap-6">
          <span>&copy; 2026 HeliosGuard Energy Systems Corp. All rights reserved.</span>
          <a href="#" className="hover:text-blue-500 transition">Privacy Policy</a>
          <a href="#" className="hover:text-blue-500 transition">Warranty Registry</a>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1"><span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span> Grid Status: Online</span>
          <span className="text-slate-700">|</span>
          <span className="text-slate-500">Global Tech Support Active</span>
        </div>
      </div>
    </footer>
  );
}
