/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sun, Video, Calculator, Settings, ShoppingBag, Heart, Search, Menu, X, Shield, Zap } from 'lucide-react';
import { CartItem, Product } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cart: CartItem[];
  wishlist: Product[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  cart,
  wishlist,
  searchQuery,
  setSearchQuery,
  darkMode,
  setDarkMode,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navItems = [
    { id: 'home', label: 'Home', icon: null },
    { id: 'solar', label: 'Solar Power', icon: Zap },
    { id: 'cctv', label: 'CCTV Security', icon: Shield },
    { id: 'calculator', label: 'Energy Calculator', icon: Calculator },
    { id: 'custom-spec', label: 'Custom Consulting', icon: Settings },
  ];

  return (
    <nav className="sticky top-0 z-50 transition-colors duration-300 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-100 dark:border-slate-800 shadow-sm" id="main-navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Slogan */}
          <div 
            className="flex items-center space-x-3 cursor-pointer select-none group"
            onClick={() => { setActiveTab('home'); setMobileMenuOpen(false); }}
            id="navbar-logo-container"
          >
            <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600 via-sky-450 to-blue-800 shadow-md group-hover:scale-105 transition-transform">
              <Sun className="absolute w-8 h-8 text-white animate-pulse" style={{ animationDuration: '3s' }} />
              <Video className="absolute w-4 h-4 text-blue-600 bottom-1.5 right-1.5 bg-white rounded-full p-0.5 shadow-sm" />
            </div>
            <div>
              <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white block font-sans">
                Aura <span className="text-blue-600 dark:text-sky-400">Energy & Shield</span>
              </span>
              <span className="text-[10px] text-slate-500 dark:text-slate-400 tracking-wider font-mono block -mt-1 uppercase">
                SOLAR • SURVEILLANCE • TRUST
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center space-x-1" id="nav-desktop-tabs">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setSearchQuery(''); }}
                  className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400 border border-blue-100/50 dark:border-blue-450/20'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                  id={`nav-tab-${item.id}`}
                >
                  {Icon && <Icon className="w-4 h-4" />}
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* Live Search & Badges Box */}
          <div className="hidden md:flex items-center space-x-4" id="nav-search-actions">
            
            {/* Search Input */}
            {['solar', 'cctv'].includes(activeTab) && (
              <div className="relative w-48 xl:w-64" id="nav-search-bar">
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-400" />
              </div>
            )}

            {/* Visual White Mode Toggle */}
            <div className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-150 dark:border-slate-700/80 shadow-sm" id="white-mode-toggle-container">
              <span className="text-[10px] font-black text-slate-500 dark:text-slate-300 font-sans tracking-tight uppercase">
                White Mode: <span className={!darkMode ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-400"}>{!darkMode ? "ON" : "OFF"}</span>
              </span>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  !darkMode ? 'bg-blue-600' : 'bg-slate-600 dark:bg-slate-700'
                }`}
                role="switch"
                aria-checked={!darkMode}
                title="Toggle White Mode (Light Mode)"
                id="white-mode-toggle"
              >
                <span
                  aria-hidden="true"
                  className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                    !darkMode ? 'translate-x-[16px]' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Wishlist Icon */}
            <button
              onClick={() => setActiveTab('wishlist')}
              className={`relative p-2.5 rounded-lg border transition ${
                activeTab === 'wishlist'
                  ? 'bg-rose-50 border-rose-100 text-rose-500 dark:bg-rose-950/30'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-500 hover:text-rose-500 dark:text-slate-400'
              }`}
              id="wishlist-trigger"
            >
              <Heart className="w-4 h-4 fill-current" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-600 px-1 text-[9px] font-bold text-white leading-none">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Shopping Cart Trigger */}
            <button
              onClick={() => setActiveTab('cart')}
              className={`relative p-2.5 rounded-lg border transition flex items-center space-x-2 ${
                activeTab === 'cart'
                  ? 'bg-blue-600 border-blue-600 text-white'
                  : 'bg-slate-50 dark:bg-slate-800 border-slate-100 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300'
              }`}
              id="cart-trigger"
            >
              <ShoppingBag className="w-4 h-4" />
              {totalCartCount > 0 && (
                <span className={`flex h-5 items-center justify-center rounded px-1.5 text-xs font-bold leading-none ${activeTab === 'cart' ? 'bg-white text-blue-600' : 'bg-blue-600 text-white'}`}>
                  {totalCartCount}
                </span>
              )}
            </button>

            {/* Admin Console trigger */}
            <button
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-bold tracking-tight transition ${
                activeTab === 'admin'
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-950'
                  : 'bg-blue-50 dark:bg-slate-800 border-blue-100 dark:border-slate-700 text-blue-700 dark:text-blue-400 hover:bg-blue-100'
              }`}
              id="admin-dashboard-trigger"
            >
              ADMIN PANEL
            </button>
          </div>

          {/* Mobile Menu & Utility Box */}
          <div className="flex lg:hidden items-center space-x-2" id="nav-mobile-utility">
            {/* Visual White Mode Toggle (Mobile) */}
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700/80" id="white-mode-toggle-container-mobile">
              <span className="text-[9px] font-black text-slate-500 dark:text-slate-300 font-sans tracking-tight uppercase">
                White Mode: <span className={!darkMode ? "text-blue-600 dark:text-blue-400 font-bold" : "text-slate-400"}>{!darkMode ? "ON" : "OFF"}</span>
              </span>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`relative inline-flex h-4 w-7 shrink-0 cursor-pointer rounded-full border border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  !darkMode ? 'bg-blue-600' : 'bg-slate-550 dark:bg-slate-700'
                }`}
                role="switch"
                aria-checked={!darkMode}
                title="Toggle White Mode (Light Mode)"
                id="white-mode-toggle-mobile"
              >
                <span
                  aria-hidden="true"
                  className={`pointer-events-none inline-block h-3 w-3 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out ${
                    !darkMode ? 'translate-x-[12px]' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
            <button
              onClick={() => setActiveTab('cart')}
              className="relative p-2 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-100 text-slate-600 dark:text-slate-400"
            >
              <ShoppingBag className="w-4 h-4" />
              {totalCartCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-blue-600 text-[9px] font-bold text-white">
                  {totalCartCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden py-4 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 transition-colors" id="mobile-navigation-drawer">
          <div className="px-4 space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                    setSearchQuery('');
                  }}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left text-sm font-medium ${
                    isActive
                      ? 'bg-blue-50 text-blue-600 dark:bg-slate-800 dark:text-blue-400'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white'
                  }`}
                  id={`mobile-nav-tab-${item.id}`}
                >
                  {Icon && <Icon className="w-4 h-4" />}
                  <span>{item.label}</span>
                </button>
              );
            })}
            
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-col space-y-2">
              <button
                onClick={() => { setActiveTab('wishlist'); setMobileMenuOpen(false); }}
                className="w-full flex items-center justify-between px-4 py-3 rounded-lg bg-rose-50 text-rose-600 text-sm font-medium dark:bg-rose-950/20"
              >
                <span className="flex items-center space-x-2">
                  <Heart className="w-4 h-4 fill-current" />
                  <span>My Wishlist</span>
                </span>
                <span className="text-xs bg-rose-600 text-white rounded px-1.5 py-0.5">{wishlist.length}</span>
              </button>
              
              <button
                onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
                className="w-full text-center px-4 py-2.5 rounded-lg bg-blue-600 text-white font-semibold text-xs font-mono"
              >
                ADMIN PANEL CONTROL
              </button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
