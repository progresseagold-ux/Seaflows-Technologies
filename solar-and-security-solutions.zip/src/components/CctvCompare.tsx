/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield, Eye, Trash2, CheckCircle2, ShoppingBag } from 'lucide-react';
import { Product } from '../types';

interface CctvCompareProps {
  compareProducts: Product[];
  onRemoveFromCompare: (id: string) => void;
  onAddToCart: (product: Product) => void;
}

export default function CctvCompare({ compareProducts, onRemoveFromCompare, onAddToCart }: CctvCompareProps) {
  if (compareProducts.length === 0) {
    return (
      <div className="bg-slate-50 dark:bg-slate-900/50 rounded-3xl p-12 text-center border border-dashed border-slate-200 dark:border-slate-800" id="cctv-compare-empty">
        <Shield className="w-12 h-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">No security products selected for review</h3>
        <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
          Browse our high-definition CCTV surveillance, cellular cameras, or recorders, and press the <b>"Compare"</b> button on the card to see detailed specifications side by side.
        </p>
      </div>
    );
  }

  // Extract all unique spec keys across the products to build complete comparison rows
  const allSpecKeys = Array.from(
    new Set(compareProducts.flatMap(p => Object.keys(p.specs || {})))
  );

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm" id="cctv-compare-dashboard">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-1.5">
            <Eye className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            Active Surveillance Comparison Arena
          </h3>
          <p className="text-xs text-slate-500">
            Compare camera factors, target intelligence, housing rating, and video streams side-by-side.
          </p>
        </div>
        <span className="text-xs font-mono font-bold bg-blue-50 dark:bg-slate-800 text-blue-700 dark:text-blue-400 px-2.5 py-1 rounded">
          {compareProducts.length} of 3 items
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 items-start divide-y md:divide-y-0 md:divide-x divide-slate-100 dark:divide-slate-800">
        
        {/* First col: Sizing labels (desktop only) */}
        <div className="hidden md:block pr-4 self-end text-xs font-bold text-slate-400 uppercase tracking-widest space-y-8 pb-4">
          <div className="h-64 flex items-end">Core Aspect</div>
          <div className="py-2 border-b border-slate-50">Retail Rate</div>
          <div className="py-2 border-b border-slate-50">Manufacturer Brand</div>
          {allSpecKeys.map(key => (
            <div key={key} className="py-2 border-b border-slate-50 truncate" title={key}>{key}</div>
          ))}
          <div className="py-2">Operational Suitability</div>
        </div>

        {/* Dynamic products loop */}
        {compareProducts.map((p) => (
          <div key={p.id} className="md:px-4 pt-4 md:pt-0 flex flex-col h-full text-xs">
            {/* Header info */}
            <div className="relative group text-center mb-6 h-64 flex flex-col justify-between items-center bg-slate-50 dark:bg-slate-800/40 p-4 rounded-2xl border border-slate-100 dark:border-slate-800/50">
              <button
                onClick={() => onRemoveFromCompare(p.id)}
                className="absolute top-2 right-2 p-1.5 rounded-full bg-white dark:bg-slate-700 shadow-sm text-slate-400 hover:text-rose-600 hover:scale-105 transition"
                title="Remove component"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>

              <img
                src={p.imageUrl}
                alt={p.name}
                className="w-24 h-24 rounded-lg object-cover shadow-sm bg-white"
              />
              <div>
                <h4 className="font-bold text-slate-800 dark:text-white mt-2 line-clamp-2 h-8" title={p.name}>
                  {p.name}
                </h4>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold mt-1">
                  {p.subCategory}
                </p>
              </div>

              <button
                onClick={() => onAddToCart(p)}
                className="w-full mt-3 py-2 bg-blue-600 dark:bg-blue-650 hover:bg-blue-700 dark:hover:bg-blue-700 text-white font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add to Order</span>
              </button>
            </div>

            {/* Spec breakdown rows */}
            <div className="space-y-4 text-slate-700 dark:text-slate-300">
              {/* Cash Rate */}
              <div className="py-2 border-b border-slate-50 dark:border-slate-800 flex justify-between md:block">
                <span className="md:hidden font-bold text-slate-400 uppercase mr-2">Rate:</span>
                <span className="text-sm font-black text-blue-600 dark:text-blue-400 font-mono">₦{p.price}</span>
              </div>

              {/* Brand */}
              <div className="py-2 border-b border-slate-50 dark:border-slate-800 flex justify-between md:block">
                <span className="md:hidden font-bold text-slate-400 uppercase mr-2">Brand:</span>
                <span className="font-semibold">{p.brand}</span>
              </div>

              {/* Specs array */}
              {allSpecKeys.map(key => {
                const specVal = p.specs[key] || "Non-specified";
                return (
                  <div key={key} className="py-2 border-b border-slate-50 dark:border-slate-800 flex justify-between md:block">
                    <span className="md:hidden font-bold text-slate-400 uppercase mr-2 truncate max-w-[120px]">{key}:</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200">{specVal}</span>
                  </div>
                );
              })}

              {/* General Warranty */}
              <div className="py-2 flex justify-between md:block leading-relaxed">
                <span className="md:hidden font-bold text-slate-400 uppercase mr-2">Warranty:</span>
                <span className="text-slate-500 font-medium">{p.warranty}</span>
              </div>
            </div>
          </div>
        ))}

        {/* Dummy grid fill when < 3 items to show encouraging helper box */}
        {compareProducts.length < 3 && (
          <div className="hidden md:flex flex-col items-center justify-center border-2 border-dashed border-slate-100 dark:border-slate-800 p-8 min-h-[300px] rounded-3xl text-center text-slate-400 self-stretch">
            <span className="text-xs font-bold uppercase tracking-widest text-slate-300 block mb-2">Slot Available</span>
            <span className="text-[10px] leading-relaxed max-w-[160px]">
              Add another CCTV kit or camera from the catalog to finalize comparison metrics.
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
