/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Calculator, Zap, Shield, Sun, HelpCircle, FileCheck, Check } from 'lucide-react';
import { ApplianceInput, CalculatorResult } from '../types';

interface ApplianceCalculatorProps {
  onRequestQuote: (calcResult: CalculatorResult, appliances: ApplianceInput[]) => void;
  userIdColor?: string;
}

const DEFAULT_APPLIANCES: ApplianceInput[] = [
  { id: '1', name: 'Smart TV & Console', quantity: 1, wattage: 120, hoursPerDay: 5 },
  { id: '2', name: 'Home Ventilation Fans', quantity: 4, wattage: 75, hoursPerDay: 12 },
  { id: '3', name: 'Inverter Refrigerator', quantity: 1, wattage: 250, hoursPerDay: 24 },
  { id: '4', name: 'Air Conditioner (1.5 HP)', quantity: 1, wattage: 1200, hoursPerDay: 6 },
  { id: '5', name: 'LED Bulbs & Lights', quantity: 12, wattage: 12, hoursPerDay: 8 },
  { id: '6', name: 'Office Laptop & PC', quantity: 2, wattage: 90, hoursPerDay: 8 },
];

export default function ApplianceCalculator({ onRequestQuote, userIdColor = 'blue' }: ApplianceCalculatorProps) {
  const [appliances, setAppliances] = useState<ApplianceInput[]>(DEFAULT_APPLIANCES);
  const [billingPlan, setBillingPlan] = useState('Standard 3-Bedroom Home');
  const [targetBackup, setTargetBackup] = useState(8); // in hours
  const [estimatedCostRange, setEstimatedCostRange] = useState({ min: 1400, max: 2800 });

  // Custom appliance state
  const [newName, setNewName] = useState('');
  const [newQty, setNewQty] = useState(1);
  const [newWatt, setNewWatt] = useState(100);
  const [newHours, setNewHours] = useState(4);

  const [calcResult, setCalcResult] = useState<CalculatorResult>({
    dailyWh: 0,
    recommendedInverterW: 0,
    recommendedBatteryWh: 0,
    recommendedBatteryAh: 0,
    recommendedPanelsNum: 0,
    recommendedPanelsW: 0,
    backupHours: 8,
    estimatedCost: 1800,
  });

  const [isSaved, setIsSaved] = useState(false);

  // Recalculate whenever appliances or constraints change
  useEffect(() => {
    let totalWh = 0;
    let peakPowerLoad = 0;

    appliances.forEach(app => {
      const dailyLoad = app.quantity * app.wattage * app.hoursPerDay;
      totalWh += dailyLoad;
      peakPowerLoad += app.quantity * app.wattage;
    });

    // Inverter size is 125% of peak load to sustain motors or appliance starting surges safely
    const inverterW = Math.max(Math.ceil(peakPowerLoad * 1.25), 1000); 

    // Battery needs: load * hours factor. Let's size battery for target backup
    const backupLoadWh = (totalWh / 24) * targetBackup;
    const recommendedBatteryWh = Math.ceil(backupLoadWh * 1.2); // 20% safety margin
    const recommendedBatteryAh = Math.ceil((recommendedBatteryWh / 48)); // assume 48V stack

    // Recommended panel quantity (assume decent peak efficiency of 5 peak-sun hours, using 450W size panels)
    const dailyPanelGenTargetWh = totalWh * 1.2; // 20% loss compensation
    const panelsRequiredSizeW = dailyPanelGenTargetWh / 5; // hours of charging
    const recommendedPanelsNum = Math.ceil(panelsRequiredSizeW / 450); 
    const recommendedPanelsW = recommendedPanelsNum * 450;

    // Estimate based on system size components
    const baseCost = (recommendedPanelsNum * 250) + (inverterW * 0.25) + (recommendedBatteryWh * 0.28) + 800;
    const roundedCost = Math.round(baseCost / 100) * 100;

    setCalcResult({
      dailyWh: Math.round(totalWh),
      recommendedInverterW: inverterW,
      recommendedBatteryWh,
      recommendedBatteryAh,
      recommendedPanelsNum,
      recommendedPanelsW,
      backupHours: targetBackup,
      estimatedCost: roundedCost,
    });
  }, [appliances, targetBackup]);

  // Adjust appliances according to standard preset templates
  const applyPreset = (preset: string) => {
    setBillingPlan(preset);
    if (preset === 'Standard 3-Bedroom Home') {
      setAppliances(DEFAULT_APPLIANCES);
      setTargetBackup(8);
    } else if (preset === 'Small Business / Office') {
      setAppliances([
        { id: 's1', name: 'Workstations & PCs', quantity: 8, wattage: 150, hoursPerDay: 9 },
        { id: 's2', name: 'High-Output LED Panels', quantity: 20, wattage: 24, hoursPerDay: 10 },
        { id: 's3', name: 'Server Rack & Switch', quantity: 1, wattage: 450, hoursPerDay: 24 },
        { id: 's4', name: 'Kitchenette Microwave', quantity: 1, wattage: 900, hoursPerDay: 1 },
        { id: 's5', name: 'Water Dispenser', quantity: 2, wattage: 150, hoursPerDay: 8 },
        { id: 's6', name: 'Office HVAC HeatPump', quantity: 2, wattage: 1800, hoursPerDay: 8 },
      ]);
      setTargetBackup(10);
    } else if (preset === 'Large Industrial Complex') {
      setAppliances([
        { id: 'i1', name: 'Heavy CNC Mill Unit', quantity: 2, wattage: 3500, hoursPerDay: 8 },
        { id: 'i2', name: 'High Bay Facility LED', quantity: 45, wattage: 80, hoursPerDay: 16 },
        { id: 'i3', name: 'Data Hub Server rack', quantity: 3, wattage: 600, hoursPerDay: 24 },
        { id: 'i4', name: 'Compressor Unit', quantity: 2, wattage: 2200, hoursPerDay: 12 },
        { id: 'i5', name: 'Breakroom Aircons', quantity: 4, wattage: 1400, hoursPerDay: 10 },
      ]);
      setTargetBackup(12);
    }
  };

  const addCustomAppliance = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;

    const newItem: ApplianceInput = {
      id: `custom-${Date.now()}`,
      name: newName,
      quantity: Math.max(newQty, 1),
      wattage: Math.max(newWatt, 5),
      hoursPerDay: Math.max(newHours, 0.5),
    };

    setAppliances([...appliances, newItem]);
    setNewName('');
    setNewQty(1);
    setNewWatt(100);
    setNewHours(4);
  };

  const updateApplianceLine = (id: string, field: keyof ApplianceInput, value: string | number) => {
    setAppliances(
      appliances.map(item => {
        if (item.id === id) {
          return { ...item, [field]: value };
        }
        return item;
      })
    );
  };

  const deleteAppliance = (id: string) => {
    setAppliances(appliances.filter(item => item.id !== id));
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="solar-calculator-module">
      {/* LEFT COLUMN: Input Configuration */}
      <div className="lg:col-span-8 flex flex-col gap-6">
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
                <Calculator className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                1. System Load Architect
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Specify your active terminal equipment load to compute highly precise industrial battery storage buffers and optimal photovoltaic sizing.
              </p>
            </div>
            {/* Presets Select */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Preset Model:</span>
              <select
                value={billingPlan}
                onChange={(e) => applyPreset(e.target.value)}
                className="p-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-800 dark:text-white"
              >
                <option value="Standard 3-Bedroom Home">Standard Residencies</option>
                <option value="Small Business / Office">Corporate Office Space</option>
                <option value="Large Industrial Complex">Heavy Industrial Complex</option>
              </select>
            </div>
          </div>

          {/* Interactive Appliances list */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase tracking-wider">
                  <th className="py-3 px-2">Equipment Load Name</th>
                  <th className="py-3 px-2 w-20 text-center">Qty</th>
                  <th className="py-3 px-2 w-24 text-center">Watts (W)</th>
                  <th className="py-3 px-2 w-28 text-center">Hours / Day</th>
                  <th className="py-3 px-2 w-24 text-right">Daily Wh</th>
                  <th className="py-3 px-2 w-12 text-center"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 dark:divide-slate-800/50">
                {appliances.map((app) => {
                  const dailyWh = app.quantity * app.wattage * app.hoursPerDay;
                  return (
                    <tr key={app.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                      <td className="py-3 px-2 font-medium text-slate-800 dark:text-slate-200">
                        <input
                          type="text"
                          value={app.name}
                          onChange={(e) => updateApplianceLine(app.id, 'name', e.target.value)}
                          className="bg-transparent border-b border-transparent hover:border-slate-300 focus:border-slate-400 dark:focus:border-slate-600 focus:outline-none w-full font-semibold focus:bg-slate-50 dark:focus:bg-slate-850 p-1 rounded"
                        />
                      </td>
                      <td className="py-3 px-2 text-center">
                        <input
                          type="number"
                          min="1"
                          value={app.quantity}
                          onChange={(e) => updateApplianceLine(app.id, 'quantity', parseInt(e.target.value, 10) || 1)}
                          className="w-16 p-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-center font-bold"
                        />
                      </td>
                      <td className="py-3 px-2 text-center">
                        <input
                          type="number"
                          min="1"
                          value={app.wattage}
                          onChange={(e) => updateApplianceLine(app.id, 'wattage', parseInt(e.target.value, 10) || 0)}
                          className="w-20 p-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-center text-blue-600 dark:text-blue-400 font-semibold"
                        />
                      </td>
                      <td className="py-3 px-2 text-center">
                        <input
                          type="number"
                          min="0.5"
                          max="24"
                          step="0.5"
                          value={app.hoursPerDay}
                          onChange={(e) => updateApplianceLine(app.id, 'hoursPerDay', parseFloat(e.target.value) || 0)}
                          className="w-20 p-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-center font-semibold text-blue-600 dark:text-blue-400"
                        />
                      </td>
                      <td className="py-3 px-2 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                        {dailyWh.toLocaleString()} Wh
                      </td>
                      <td className="py-3 px-2 text-center">
                        <button
                          onClick={() => deleteAppliance(app.id)}
                          className="text-slate-400 hover:text-rose-600 p-1 rounded transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Quick inline form to append equipment load */}
          <form onSubmit={addCustomAppliance} className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
            <div className="sm:col-span-5">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">New Element Name</label>
              <input
                type="text"
                placeholder="e.g. Microwave, Heavy Laser, CCTV server"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Qty</label>
              <input
                type="number"
                min="1"
                value={newQty}
                onChange={(e) => setNewQty(parseInt(e.target.value, 10) || 1)}
                className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-center"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Watts</label>
              <input
                type="number"
                min="5"
                value={newWatt}
                onChange={(e) => setNewWatt(parseInt(e.target.value, 10) || 100)}
                className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-center"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1 block">Hours</label>
              <input
                type="number"
                step="0.5"
                max="24"
                min="0.5"
                value={newHours}
                onChange={(e) => setNewHours(parseFloat(e.target.value) || 4)}
                className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-center rounded-lg"
              />
            </div>
            <div className="sm:col-span-1">
              <button
                type="submit"
                className="w-full py-2.5 bg-slate-950 dark:bg-slate-800 hover:bg-slate-800 border border-slate-300 dark:border-slate-600 text-white rounded-lg flex items-center justify-center font-bold"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>

        {/* 2. Backup autonomy slider */}
        <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h2 className="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2 mb-2">
            <Sun className="w-5 h-5 text-blue-500" />
            2. Active Backup Demands
          </h2>
          <p className="text-xs text-slate-500 mb-6">
            Drag the gauge to match your facility's active backup timeline configuration goals during grid blackout scenarios.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="flex-1 w-full">
              <div className="flex justify-between text-xs font-semibold mb-2 text-slate-400">
                <span>Minimal Autonomy (2 hrs)</span>
                <span className="text-blue-600 dark:text-blue-400 font-bold">{targetBackup} Blackout Hours Sized</span>
                <span>Off-Grid Peak Coverage (24 hrs)</span>
              </div>
              <input
                type="range"
                min="2"
                max="24"
                value={targetBackup}
                onChange={(e) => setTargetBackup(parseInt(e.target.value, 10))}
                className="w-full accent-blue-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
              />
              <div className="grid grid-cols-5 text-[10px] font-mono text-slate-400 mt-2 text-center">
                <span>2h (LEDs)</span>
                <span>6h (Essential)</span>
                <span>12h (Medium block)</span>
                <span>18h (Corporate block)</span>
                <span>24h (Crucial Server)</span>
              </div>
            </div>

            {/* Quick Math KPI summary */}
            <div className="bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 rounded-2xl p-4 w-full sm:w-64 text-center">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Target Backup Consumption</span>
              <span className="text-2xl font-bold font-mono text-slate-800 dark:text-white">
                {((calcResult.dailyWh / 24) * targetBackup / 1000).toFixed(2)} kWh
              </span>
              <span className="text-xs text-slate-500 block mt-1">Sustained under target runtime</span>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Results Output & Graphic Meter */}
      <div className="lg:col-span-4 flex flex-col gap-6">
        <aside className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-lg p-6 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-800 dark:text-white">Sizing Report</h2>
            <div className="w-8 h-8 bg-blue-50 dark:bg-slate-800 rounded-full flex items-center justify-center">
              <span className="text-blue-600 dark:text-blue-400 text-xs font-mono font-bold">kW</span>
            </div>
          </div>

          <div className="space-y-5 flex-1">
            {/* Sizing Blueprint Card */}
            <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-800 dark:to-slate-800/40 rounded-2xl border border-blue-100/65 dark:border-slate-700 flex flex-col">
              <div className="text-[10px] font-bold text-blue-600 dark:text-blue-400 mb-2 uppercase tracking-wider font-mono">Recommended Sizing Specs</div>
              
              {/* Daily requirement indicator */}
              <div className="mb-4">
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Estimated Daily Load</span>
                <span className="text-2xl font-black text-slate-800 dark:text-white font-mono">{(calcResult.dailyWh / 1000).toFixed(2)} kW/h</span>
              </div>

              {/* Dynamic technical sizing grids */}
              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-blue-100 dark:border-slate-700 text-xs">
                <div>
                  <span className="text-slate-400 font-semibold block text-[10px] uppercase">Solar Array</span>
                  <span className="font-extrabold text-slate-800 dark:text-slate-100 font-mono">
                    {calcResult.recommendedPanelsNum} x 450W
                  </span>
                  <p className="text-[10px] text-slate-500">{(calcResult.recommendedPanelsW / 1000).toFixed(2)} kW Plant</p>
                </div>
                
                <div>
                  <span className="text-slate-400 font-semibold block text-[10px] uppercase">Smart Inverter</span>
                  <span className="font-extrabold text-slate-800 dark:text-slate-100 font-mono">
                    {(calcResult.recommendedInverterW / 1000).toFixed(1)} kW Rating
                  </span>
                  <p className="text-[10px] text-slate-500">Pure Sine-Wave</p>
                </div>

                <div className="mt-1">
                  <span className="text-slate-400 font-semibold block text-[10px] uppercase">LiFePO4 Storage</span>
                  <span className="font-extrabold text-slate-800 dark:text-slate-100 font-mono">
                    {(calcResult.recommendedBatteryWh / 1000).toFixed(2)} kWh
                  </span>
                  <p className="text-[10px] text-slate-500">~{calcResult.recommendedBatteryAh} Ah @ 48V Bank</p>
                </div>

                <div className="mt-1">
                  <span className="text-slate-400 font-semibold block text-[10px] uppercase">EST. COST SUMMARY</span>
                  <span className="font-black text-blue-600 dark:text-blue-400 font-mono text-sm">
                    ₦{calcResult.estimatedCost.toLocaleString()}
                  </span>
                  <p className="text-[10px] text-slate-500">Hardware & Install</p>
                </div>
              </div>
            </div>

            {/* Micro visual graphic indicator */}
            <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 border border-slate-100 dark:border-slate-700/80">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-2">Autonomy Balance Indicator</span>
              <div className="flex items-center gap-2 mb-1">
                <div className="flex-1 bg-slate-200 dark:bg-slate-700 h-4 rounded-full overflow-hidden flex">
                  {/* Solar Share */}
                  <div 
                    title="Solar Contribution" 
                    className="bg-sky-400 h-full transition-all duration-500" 
                    style={{ width: `${Math.min(90, Math.max(10, (calcResult.recommendedPanelsW / (calcResult.dailyWh || 1000)) * 100))}%` }}
                  ></div>
                  {/* Battery Share */}
                  <div 
                    title="Battery Storage buffer" 
                    className="bg-blue-600 h-full transition-all duration-500" 
                    style={{ width: `${Math.min(90, Math.max(10, (calcResult.recommendedBatteryWh / (calcResult.dailyWh || 1000)) * 100))}%` }}
                  ></div>
                </div>
                <span className="text-[11px] font-mono font-bold">Auton%</span>
              </div>
              <div className="flex justify-between text-[9px] text-slate-400">
                <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-sky-400 rounded-full"></span> Solar Sizing</span>
                <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 bg-blue-600 rounded-full"></span> Battery Autonomy</span>
              </div>
            </div>
          </div>

          {/* Action Call buttons */}
          <div className="flex flex-col gap-3 mt-6">
            <button
              onClick={() => {
                onRequestQuote(calcResult, appliances);
                setIsSaved(true);
                setTimeout(() => setIsSaved(false), 3000);
              }}
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 dark:bg-blue-600 dark:hover:bg-blue-700 text-white font-bold rounded-2xl transition-colors shadow-md flex items-center justify-center gap-2"
            >
              {isSaved ? (
                <>
                  <Check className="w-4 h-4 text-emerald-500 dark:text-emerald-950 font-bold" />
                  <span>Request Sent to Portal!</span>
                </>
              ) : (
                <>
                  <FileCheck className="w-4 h-4" />
                  <span>Request Formal Consultation</span>
                </>
              )}
            </button>
            
            <button
              onClick={handlePrint}
              className="w-full py-2 bg-transparent text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white border border-slate-200 dark:border-slate-800 font-mono text-xs rounded-xl"
            >
              Print Specifications Form
            </button>
          </div>

          <p className="text-[9px] text-center text-slate-400 mt-4 leading-relaxed">
            Sizing formulas compliant with off-grid building standards. Solar peak production calculated for typical solar zones with standard radiation maps.
          </p>
        </aside>
      </div>
    </div>
  );
}
