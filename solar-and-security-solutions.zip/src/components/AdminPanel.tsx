/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, Inbox, Package, Shield, Settings, TrendingUp, AlertTriangle, 
  Trash2, Edit, Save, CheckCircle2, Star, Mail, Phone, Calendar, UserPlus 
} from 'lucide-react';
import { Product, Order, QuotationRequest, AnalyticsSummary } from '../types';

interface AdminPanelProps {
  products: Product[];
  orders: Order[];
  quotes: QuotationRequest[];
  analytics: AnalyticsSummary;
  onAddProduct: (item: Partial<Product>) => void;
  onEditProduct: (id: string, item: Partial<Product>) => void;
  onDeleteProduct: (id: string) => void;
  onChangeOrderStatus: (orderId: string, status: Order['status']) => void;
  onChangeQuoteStatus: (quoteId: string, status: QuotationRequest['status']) => void;
}

export default function AdminPanel({
  products,
  orders,
  quotes,
  analytics,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  onChangeOrderStatus,
  onChangeQuoteStatus
}: AdminPanelProps) {
  const [adminTab, setAdminTab] = useState<'analytics' | 'inventory' | 'register' | 'orders' | 'quotes'>('analytics');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Adding product state
  const [addName, setAddName] = useState('');
  const [addCategory, setAddCategory] = useState<'solar' | 'cctv'>('solar');
  const [addSubCategory, setAddSubCategory] = useState('panels');
  const [addBrand, setAddBrand] = useState('');
  const [addPrice, setAddPrice] = useState(150);
  const [addStock, setAddStock] = useState(25);
  const [addDesc, setAddDesc] = useState('');
  const [addWarranty, setAddWarranty] = useState('5-year standard warranty');
  const [addImageUrl, setAddImageUrl] = useState('');

  // Editing pricing or stock inline
  const [editProductId, setEditProductId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState(0);
  const [editStock, setEditStock] = useState(0);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addName.trim() || !addBrand.trim()) return;

    const finalImage = addImageUrl.trim() || (addCategory === 'solar' 
      ? 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=600&auto=format&fit=crop&q=80'
      : 'https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=600&auto=format&fit=crop&q=80');

    const productPayload: Partial<Product> = {
      name: addName,
      category: addCategory,
      subCategory: addSubCategory,
      brand: addBrand,
      price: Math.max(addPrice, 1),
      stock: Math.max(addStock, 0),
      description: addDesc || 'Premium heavy duty architectural component.',
      warranty: addWarranty,
      imageUrl: finalImage,
      specs: {
        "Nominal Voltage": "48V",
        "Efficiency Index": "High rating",
        "Authorized Deployment": "Yes"
      },
      installationDetails: "Standard mounting protocols, refer to service manuals."
    };

    onAddProduct(productPayload);

    setSuccessMsg('Corporate inventory item registered successfully!');
    setTimeout(() => {
      setSuccessMsg(null);
    }, 4500);

    // reset fields
    setAddName('');
    setAddBrand('');
    setAddPrice(150);
    setAddStock(25);
    setAddDesc('');
    setAddImageUrl('');
  };

  const handleSaveInline = (id: string) => {
    onEditProduct(id, {
      price: editPrice,
      stock: editStock,
    });
    setEditProductId(null);
  };

  const triggerEditMode = (p: Product) => {
    setEditProductId(p.id);
    setEditPrice(p.price);
    setEditStock(p.stock);
  };

  return (
    <div className="flex flex-col gap-8" id="corporate-management-console">
      {/* Header control board */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-6 bg-slate-50 dark:bg-slate-900 p-6 rounded-3xl">
        <div>
          <h2 className="text-2xl font-black text-slate-850 dark:text-white flex items-center gap-1.5 font-sans">
            <Settings className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            HeliosGuard Operations Dashboard
          </h2>
          <p className="text-xs text-slate-400 mt-1 uppercase font-mono tracking-widest font-bold">
            Live ERP Central Command Page
          </p>
        </div>

        {/* Console Nav buttons */}
        <div className="flex flex-wrap gap-2 text-xs font-bold uppercase tracking-wider">
          <button
            onClick={() => setAdminTab('analytics')}
            className={`px-4 py-2.5 rounded-xl transition ${adminTab === 'analytics' ? 'bg-slate-950 text-white dark:bg-blue-600 dark:text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-700 text-slate-600 dark:text-slate-350'}`}
          >
            Sales Analytics
          </button>
          <button
            onClick={() => setAdminTab('inventory')}
            className={`px-4 py-2.5 rounded-xl transition ${adminTab === 'inventory' ? 'bg-slate-950 text-white dark:bg-blue-600 dark:text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-700 text-slate-600 dark:text-slate-350'}`}
          >
            Products ({products.length})
          </button>
          <button
            onClick={() => setAdminTab('register')}
            className={`px-4 py-2.5 rounded-xl transition ${adminTab === 'register' ? 'bg-slate-950 text-white dark:bg-blue-600 dark:text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-700 text-slate-600 dark:text-slate-350'}`}
          >
            Register New Inventory Item
          </button>
          <button
            onClick={() => setAdminTab('orders')}
            className={`px-4 py-2.5 rounded-xl transition ${adminTab === 'orders' ? 'bg-slate-950 text-white dark:bg-blue-600 dark:text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-700 text-slate-600 dark:text-slate-350'}`}
          >
            Live Orders ({orders.length})
          </button>
          <button
            onClick={() => setAdminTab('quotes')}
            className={`px-4 py-2.5 rounded-xl transition ${adminTab === 'quotes' ? 'bg-slate-950 text-white dark:bg-blue-600 dark:text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-700 text-slate-600 dark:text-slate-350'}`}
          >
            Consulting Quotes ({quotes.length})
          </button>
        </div>
      </div>

      {/* VIEW 1: SALES ANALYTICS */}
      {adminTab === 'analytics' && (
        <div className="space-y-8">
          {/* Quick Metrics grid */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Total Sales Cash</span>
              <span className="text-2xl font-black font-mono text-slate-900 dark:text-white mt-1">₦{analytics.revenue.toLocaleString()}</span>
              <p className="text-[10px] text-emerald-500 font-semibold mt-2 flex items-center gap-1">
                <TrendingUp className="w-3 h-3" /> +15.5% Growth metric
              </p>
            </div>

            <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">MW Power Sized</span>
              <span className="text-2xl font-black font-mono text-slate-900 dark:text-white mt-1">{analytics.powerInstalledKw} MW</span>
              <p className="text-[10px] text-slate-400 font-medium mt-2">Active installations</p>
            </div>

            <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Pending Consultations</span>
              <span className="text-2xl font-black font-mono text-blue-600 dark:text-blue-400 mt-1">{quotes.filter(q => q.status === 'pending').length} requests</span>
              <p className="text-[10px] text-rose-500 font-semibold mt-2 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3 animate-pulse" /> Action required
              </p>
            </div>

            <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-100 dark:border-slate-700 flex flex-col justify-between shadow-sm">
              <span className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">Inventory Alerts</span>
              <span className={`text-2xl font-black font-mono mt-1 ${products.filter(p => p.stock < 15).length > 0 ? 'text-red-500' : 'text-slate-800'}`}>
                {products.filter(p => p.stock < 15).length} Items Low
              </span>
              <p className="text-[10px] text-slate-400 font-medium mt-2">Auto threshold triggers</p>
            </div>
          </div>

          {/* SVG Visual corporate reports */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700">
              <h3 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider mb-4">Peak Grid Load Sizing Analysis (2026)</h3>
              <div className="h-48 w-full flex items-end gap-3 justify-between pt-6 border-b border-l border-slate-100 dark:border-slate-700 px-4">
                {/* 5 clean column bar segments */}
                {[
                  { m: 'Jan', val: 70, label: '840 kW' },
                  { m: 'Feb', val: 120, label: '1440 kW' },
                  { m: 'Mar', val: 180, label: '2160 kW' },
                  { m: 'Apr', val: 240, label: '2880 kW' },
                  { m: 'May (Now)', val: 310, label: '3720 kW' },
                ].map((item, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center group">
                    <div className="text-[9px] text-slate-400 pb-1 opacity-0 group-hover:opacity-100 transition whitespace-nowrap">{item.label}</div>
                    <div 
                      className="w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-lg transition-all duration-1000 origin-bottom" 
                      style={{ height: `${item.val / 3.3}px` }}
                    ></div>
                    <span className="text-[10px] font-bold text-slate-400 mt-2">{item.m}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-white uppercase tracking-wider mb-2">Systems Online telemetry</h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  Autonomous power grids, smart NVR monitoring and CCTV cellular lines performance are actively verified by the remote telemetry hub every 5 minutes.
                </p>
              </div>
              <div className="p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-xs text-emerald-800 dark:text-emerald-400">
                <span className="font-bold flex items-center gap-1.5 mb-1">
                  <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                  HELIOS Cloud Server: OPERATIONAL
                </span>
                Active node clusters: 24/24. Packet delivery latency average: 14ms.
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: PRODUCT MANAGEMENT & INVENTORY LIST */}
      {adminTab === 'inventory' && (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-150 dark:border-slate-700 shadow-sm overflow-x-auto">
          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-800 dark:text-white">Active Sized Catalog List</h3>
              <p className="text-xs text-slate-400">Manage rates, view stock status levels, and update existing equipment.</p>
            </div>
            <button
              onClick={() => setAdminTab('register')}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 self-start uppercase tracking-wider"
              id="goto-register-btn"
            >
              <Plus className="w-4 h-4" /> Register New Item
            </button>
          </div>
          <table className="w-full text-xs font-semibold text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-700 text-slate-404 font-bold uppercase tracking-wider">
                <th className="py-3 px-2">Imagery</th>
                <th className="py-3 px-2">Component Specifications Name</th>
                <th className="py-3 px-2">Category</th>
                <th className="py-3 px-2 text-center">Price Rate</th>
                <th className="py-3 px-2 text-center font-bold">Qty Stock</th>
                <th className="py-3 px-2 text-right">Settings</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-55 dark:divide-slate-700/50">
              {products.map((p) => {
                const isLow = p.stock < 15;
                const isEditingThis = editProductId === p.id;
                return (
                  <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition">
                    <td className="py-3 px-2">
                      <img
                        src={p.imageUrl}
                        alt={p.name}
                        className="w-10 h-10 object-cover rounded-lg border bg-white"
                      />
                    </td>
                    <td className="py-3 px-2">
                      <span className="font-extrabold text-slate-900 dark:text-white block line-clamp-1">{p.name}</span>
                      <span className="text-[10px] text-slate-405 font-mono">{p.brand}</span>
                    </td>
                    <td className="py-3 px-2">
                      <span className="text-[10px] uppercase font-bold text-slate-450 bg-slate-100 dark:bg-slate-750 px-1.5 py-0.5 rounded">
                        {p.category}
                      </span>
                    </td>

                    {/* EDIT PRICE RATE */}
                    <td className="py-3 px-2 text-center">
                      {isEditingThis ? (
                        <input
                          type="number"
                          value={editPrice}
                          onChange={(e) => setEditPrice(parseInt(e.target.value, 10) || 0)}
                          className="w-20 p-1 font-mono font-bold text-center border rounded bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white"
                        />
                      ) : (
                        <span className="font-bold text-blue-600 dark:text-blue-400 font-mono">₦{p.price}</span>
                      )}
                    </td>

                    {/* EDIT STOCK LEVEL */}
                    <td className="py-3 px-2 text-center">
                      {isEditingThis ? (
                        <input
                          type="number"
                          value={editStock}
                          onChange={(e) => setEditStock(parseInt(e.target.value, 10) || 0)}
                          className="w-16 p-1 font-bold text-center border rounded bg-slate-50 dark:bg-slate-900 text-slate-800 dark:text-white"
                        />
                      ) : (
                        <span className={`px-2 py-0.5 rounded font-bold ${isLow ? 'bg-sky-100 dark:bg-red-950/40 text-blue-650 dark:text-blue-400' : 'text-slate-700 dark:text-slate-350 bg-slate-100 dark:bg-slate-700'}`}>
                          {p.stock} units
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-2 text-right">
                      <div className="flex items-center justify-end gap-2 text-slate-400">
                        {isEditingThis ? (
                          <button
                            onClick={() => handleSaveInline(p.id)}
                            className="text-emerald-600 hover:text-emerald-700 p-1 bg-emerald-50 dark:bg-emerald-950/20 rounded transition"
                            title="Commit price/stock upload"
                          >
                            <Save className="w-4 h-4" />
                          </button>
                        ) : (
                          <button
                            onClick={() => triggerEditMode(p)}
                            className="text-blue-600 hover:text-blue-700 p-1 rounded hover:bg-blue-50 dark:hover:bg-slate-700/50"
                            title="Modify product inline"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => onDeleteProduct(p.id)}
                          className="text-slate-400 hover:text-rose-600 p-1 rounded"
                          title="Purge product allocation"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* VIEW 2.5: REGISTER NEW INVENTORY ITEM */}
      {adminTab === 'register' && (
        <div className="max-w-2xl mx-auto w-full bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-150 dark:border-slate-700 shadow-sm">
          <div className="mb-6">
            <h3 className="text-lg font-black text-slate-850 dark:text-white flex items-center gap-2">
              <Plus className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              Register New Inventory Item
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Add products, panels, cameras, or NVR systems into the live public operations catalog.
            </p>
          </div>

          {successMsg && (
            <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-center gap-2.5 text-xs font-bold text-emerald-800 dark:text-emerald-400 animate-pulse">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleAddSubmit} className="space-y-5 text-xs font-medium">
            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Product Title / Spec Name</label>
              <input
                type="text"
                required
                placeholder="e.g. Aura Bifacial Panel 600W"
                value={addName}
                onChange={(e) => setAddName(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Category Domain</label>
                <select
                  value={addCategory}
                  onChange={(e) => {
                    const cat = e.target.value as 'solar' | 'cctv';
                    setAddCategory(cat);
                    setAddSubCategory(cat === 'solar' ? 'panels' : 'cameras');
                  }}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="solar">Solar Energy Solution</option>
                  <option value="cctv">CCTV Surveillance Safety</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Subcategory Classification</label>
                <select
                  value={addSubCategory}
                  onChange={(e) => setAddSubCategory(e.target.value)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white uppercase font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  {addCategory === 'solar' ? (
                    <>
                      <option value="panels">Solar panels</option>
                      <option value="inverters">Inverters</option>
                      <option value="batteries">Batteries</option>
                      <option value="charge_controllers">Charge controllers</option>
                      <option value="accessories">Accessories & core cables</option>
                    </>
                  ) : (
                    <>
                      <option value="cameras">CCTV cameras & solar-wire</option>
                      <option value="dvrs">DVR/NVR systems</option>
                      <option value="accessories">Surveillance Accessories</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Commercial Price (₦)</label>
                <input
                  type="number"
                  min="1"
                  required
                  value={addPrice}
                  onChange={(e) => setAddPrice(parseInt(e.target.value, 10) || 0)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-blue-600 dark:text-blue-400 font-bold font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Initial Stock Sizing</label>
                <input
                  type="number"
                  min="0"
                  required
                  value={addStock}
                  onChange={(e) => setAddStock(parseInt(e.target.value, 10) || 0)}
                  className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg font-bold font-mono focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Brand Name / Manufacturer</label>
              <input
                type="text"
                required
                placeholder="e.g. Huawei Smart, Aura Guard"
                value={addBrand}
                onChange={(e) => setAddBrand(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white font-semibold focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Overview/Description Details</label>
              <textarea
                placeholder="Describe product performance credentials, specs, warranties..."
                rows={3}
                value={addDesc}
                onChange={(e) => setAddDesc(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg resize-none text-slate-800 dark:text-white focus:outline-none focus:ring-1 focus:ring-blue-600"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Imagery Hyperlink URL (Custom Solar or CCTV Image URL)</label>
              <input
                type="text"
                placeholder="https://images.unsplash.com/..."
                value={addImageUrl}
                onChange={(e) => setAddImageUrl(e.target.value)}
                className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-600 font-mono text-[10px]"
              />
              <p className="text-[10px] text-slate-400 mt-1 italic">
                Provide an image URL to replace default placeholder graphics. Enter any Unsplash, hosting, or local static path.
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md tracking-wider transition uppercase"
            >
              Upload to Corporate Public Catalog
            </button>
          </form>
        </div>
      )}

      {/* VIEW 3: LIVE ACTIVE CLIENT ORDERS */}
      {adminTab === 'orders' && (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-150 dark:border-slate-700 shadow-sm">
          <h3 className="text-base font-bold text-slate-800 dark:text-white mb-4">Operations Client Orders Flow</h3>
          {orders.length === 0 ? (
            <div className="text-center py-12 text-slate-400 font-medium">
              <Inbox className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <span>No logged client sales active inside current frame.</span>
            </div>
          ) : (
            <div className="space-y-6">
              {orders.map((o) => (
                <div key={o.id} className="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs flex flex-col md:flex-row gap-6 justify-between items-start">
                  
                  {/* Left block: Buyer credentials */}
                  <div className="space-y-3 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-400 uppercase tracking-widest font-mono">Invoice Code:</span>
                      <span className="font-extrabold text-blue-600 dark:text-blue-400 font-mono text-sm uppercase">{o.id}</span>
                      <span className="text-[10px] text-slate-400 font-mono font-medium">Submitted {new Date(o.createdAt).toLocaleString()}</span>
                    </div>

                    <div className="space-y-1 font-semibold text-slate-700 dark:text-slate-300">
                      <p className="font-extrabold text-slate-900 dark:text-white text-sm">{o.customerName}</p>
                      <div className="flex items-center gap-4 text-[11px] text-slate-500">
                        <span className="flex items-center gap-1"><Mail className="w-3 h-3 text-slate-400" /> {o.customerEmail}</span>
                        <span className="flex items-center gap-1"><Phone className="w-3 h-3 text-slate-400" /> {o.customerPhone}</span>
                      </div>
                      <p className="text-[11px] mt-1 text-slate-500 font-serif">Delivery Site: {o.address}</p>
                    </div>

                    {/* Sized items list table */}
                    <div className="pt-2">
                      <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Commercial items allocation:</span>
                      <div className="space-y-1 pl-3 border-l-2 border-slate-200 dark:border-slate-700">
                        {o.items.map((item, idy) => (
                          <div key={idy} className="text-xs font-semibold text-slate-805 dark:text-slate-200 flex justify-between max-w-lg">
                            <span>• {item.productName} (Qty {item.quantity} units)</span>
                            <span className="font-mono font-bold text-slate-500">₦{item.price * item.quantity}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Right block: Status action and totals summary */}
                  <div className="flex flex-col items-end gap-3 self-stretch md:self-auto justify-between border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-700 pt-4 md:pt-0 md:pl-6 min-w-[200px]">
                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-400 uppercase block">Invoice Total cash</span>
                      <span className="text-xl font-black font-mono text-slate-900 dark:text-white">₦{o.totalPrice.toLocaleString()}</span>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-mono">Via: {o.paymentMethod.replace('_', ' ').toUpperCase()}</p>
                    </div>

                    {/* Status updater select dropdown */}
                    <div className="w-full">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1 text-right">Dispatch Status</label>
                      <select
                        value={o.status}
                        onChange={(e) => onChangeOrderStatus(o.id, e.target.value as Order['status'])}
                        className={`w-full p-2 rounded-lg text-xs font-bold text-center border focus:outline-none uppercase ${
                          o.status === 'delivered' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600' :
                          o.status === 'shipped' ? 'bg-blue-500/10 border-blue-500/30 text-blue-600' :
                          o.status === 'processing' ? 'bg-sky-500/10 border-sky-500/20 text-sky-600' :
                          'bg-rose-50 border-rose-100 text-rose-550'
                        }`}
                      >
                        <option value="pending">⏳ Pending Verification</option>
                        <option value="processing">⚙️ In Processing</option>
                        <option value="shipped">🚀 Shipped Out</option>
                        <option value="delivered">✅ Delivered site-verified</option>
                      </select>
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIEW 4: CONSULTATION QUOTATION REQUESTS */}
      {adminTab === 'quotes' && (
        <div className="bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-150 dark:border-slate-700 shadow-sm">
          <h3 className="text-base font-bold text-slate-800 dark:text-white mb-4">Incoming Consultation Enquiries</h3>
          {quotes.length === 0 ? (
            <div className="text-center py-12 text-slate-400 font-medium">
              <Inbox className="w-10 h-10 mx-auto mb-2 text-slate-300" />
              <span>No custom consultation requests active inside current frame history.</span>
            </div>
          ) : (
            <div className="space-y-6">
              {quotes.map((q) => (
                <div key={q.id} className="p-5 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl text-xs flex flex-col gap-6 justify-between">
                  
                  <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-400 uppercase tracking-widest font-mono">Inquiry Ref:</span>
                        <span className="font-extrabold text-blue-600 dark:text-blue-400 font-mono text-sm">{q.id}</span>
                        <span className="text-[10px] text-slate-407 font-mono">Filed {new Date(q.createdAt).toLocaleDateString()}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${q.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : q.status === 'reviewed' ? 'bg-blue-100 text-blue-700' : 'bg-sky-100 text-sky-700 animate-pulse'}`}>
                          {q.status}
                        </span>
                      </div>
                      
                      <p className="font-extrabold text-slate-900 dark:text-white text-medium pt-1">
                        Client: {q.customer.name}
                      </p>
                      <div className="flex items-center gap-4 text-[11px] text-slate-500">
                        <span className="flex"><Mail className="w-3.5 h-3.5 text-slate-400 mr-1" /> {q.customer.email}</span>
                        <span className="flex"><Phone className="w-3.5 h-3.5 text-slate-400 mr-1" /> {q.customer.phone}</span>
                      </div>
                    </div>

                    {/* Status updater selector */}
                    <div className="w-full sm:w-48 text-right">
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Review Step Status</label>
                      <select
                        value={q.status}
                        onChange={(e) => onChangeQuoteStatus(q.id, e.target.value as QuotationRequest['status'])}
                        className="p-1 px-2.5 w-full bg-white dark:bg-slate-800 border rounded-lg text-xs font-bold text-slate-800 dark:text-white"
                      >
                        <option value="pending">⏳ Pending review</option>
                        <option value="reviewed">👀 Sized / Under Analysis</option>
                        <option value="completed">✅ Final quotation dispatched</option>
                      </select>
                    </div>

                  </div>

                  {/* Sizing demands summary */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 bg-slate-100 dark:bg-slate-850 rounded-xl font-semibold text-slate-705 dark:text-slate-300">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Facility Type</span>
                      <span className="text-slate-850 dark:text-slate-100 capitalize">{q.customer.buildingType}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Sized Area / Rooms</span>
                      <span className="text-slate-850 dark:text-slate-100 font-mono">{q.customer.roomsOrOffices}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Blackout Target Backup</span>
                      <span className="text-slate-850 dark:text-slate-100 font-mono">{q.customer.backupHours} black-hours</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block">Indicated Budget</span>
                      <span className="text-slate-850 dark:text-slate-100">{q.customer.budgetRange}</span>
                    </div>
                  </div>

                  {/* System details */}
                  <div className="flex flex-col gap-4 text-xs">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Target Surveillance Coverage Area requested</span>
                      <p className="bg-white dark:bg-slate-850 p-3 rounded-lg border border-slate-100 dark:border-slate-800 leading-relaxed italic text-slate-500 font-serif">
                        "{q.customer.securityArea || 'Whole building exterior and backyard access coverage'}"
                      </p>
                    </div>

                    {q.customer.notes && (
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Additional Project Brief Notes</span>
                        <p className="bg-white dark:bg-slate-850 p-3 rounded-lg border border-slate-100 dark:border-slate-800 leading-relaxed text-slate-500 font-mono">
                          {q.customer.notes}
                        </p>
                      </div>
                    )}

                    {/* Auto Advisory System recommended config */}
                    {q.recommendations && (
                      <div className="p-4 bg-gradient-to-br from-blue-50/50 to-indigo-50/50 dark:from-slate-850 dark:to-slate-850 border border-indigo-100 dark:border-slate-700/80 rounded-xl leading-relaxed text-slate-700">
                        <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase block font-serif tracking-wide">
                          Recommended System Configuration advice:
                        </span>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 font-bold mb-3">
                          <p className="text-slate-800 dark:text-slate-205">☀️ Recommended Solar: <span className="text-blue-600 dark:text-blue-400">{q.recommendations.solarSystem}</span></p>
                          <p className="text-slate-850 dark:text-slate-205">🛡️ CCTV Security Option: <span className="text-blue-500 dark:text-blue-400">{q.recommendations.cctvSystem}</span></p>
                          <p className="text-slate-850 dark:text-slate-205">💰 Est Price Allocation: <span className="text-slate-900 dark:text-white font-mono">₦{q.recommendations.estimatedCost}</span></p>
                        </div>

                        {q.recommendations.aiAnalysis && (
                          <div className="pt-2 border-t border-indigo-100 dark:border-slate-700">
                            <span className="text-[10px] text-slate-450 uppercase font-mono font-bold block mb-1">Consulting Heuristic Report Output:</span>
                            <p className="italic text-[11px] text-slate-550 dark:text-slate-350">{q.recommendations.aiAnalysis}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
