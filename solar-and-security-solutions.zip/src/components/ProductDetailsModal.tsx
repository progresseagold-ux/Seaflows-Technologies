/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Star, ShieldAlert, BadgeCheck, Wrench, ChevronRight, MessageSquare, PlusCircle } from 'lucide-react';
import { Product, Review } from '../types';

interface ProductDetailsModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onAddReview: (productId: string, review: Review) => void;
  wishlist: Product[];
  onToggleWishlist: (product: Product) => void;
}

export default function ProductDetailsModal({
  product,
  onClose,
  onAddToCart,
  onAddReview,
  wishlist,
  onToggleWishlist,
}: ProductDetailsModalProps) {
  const [userName, setUserName] = useState('');
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [activeTab, setActiveTab] = useState<'specs' | 'install' | 'reviews'>('specs');

  const isInWishlist = wishlist.some(p => p.id === product.id);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !comment.trim()) return;

    const newReview: Review = {
      id: `rev-${Date.now()}`,
      user: userName,
      rating,
      comment,
      date: new Date().toISOString().split('T')[0],
    };

    onAddReview(product.id, newReview);
    setUserName('');
    setRating(5);
    setComment('');
  };

  return (
    <div className="fixed inset-0 z-55 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true" id="specifications-modal-overlay">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        
        {/* Dark overlay backdrop */}
        <div 
          onClick={onClose}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
          aria-hidden="true"
        ></div>

        {/* Trick to center modal on desktop */}
        <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

        {/* Modal cardboard */}
        <div className="inline-block align-bottom bg-white dark:bg-slate-900 rounded-3xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-4xl sm:w-full border border-slate-100 dark:border-slate-800">
          
          {/* Header */}
          <div className="flex justify-between items-center px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/40">
            <div>
              <span className="px-2.5 py-0.5 bg-blue-50 dark:bg-slate-800 text-blue-600 dark:text-blue-400 text-[10px] font-mono font-bold tracking-widest uppercase rounded">
                {product.category === 'solar' ? 'Solar Components' : 'CCTV Surveillance'} • {product.subCategory}
              </span>
              <h2 className="text-base font-black text-slate-800 dark:text-white mt-1">
                {product.name}
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-850"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-8 max-h-[75vh] overflow-y-auto">
            
            {/* Left side: Images and rapid actions */}
            <div className="md:col-span-5 flex flex-col gap-4">
              <div className="w-full h-64 bg-slate-100 rounded-2xl overflow-hidden relative border border-slate-200">
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                <span className={`absolute top-3 left-3 px-2 py-1 ${product.stock > 10 ? 'bg-emerald-600' : 'bg-amber-600'} text-white text-[9px] font-bold uppercase rounded`}>
                  {product.stock > 10 ? 'Standard Stock' : 'Limited Storage'} ({product.stock} left)
                </span>
              </div>

              {/* Specs KPI box */}
              <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 text-xs">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-slate-400 font-bold uppercase tracking-wide text-[10px]">Commercial Cost</span>
                  <span className="text-lg font-black text-blue-600 dark:text-blue-400 font-mono">₦{product.price}</span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-slate-400 font-bold uppercase tracking-wide text-[10px]">Warranty Statement</span>
                  <span className="text-slate-800 dark:text-slate-200 font-medium">{product.warranty}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold uppercase tracking-wide text-[10px]">Rating Index</span>
                  <span className="flex items-center gap-1 font-bold text-slate-800 dark:text-slate-200">
                    <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                    {product.rating ? product.rating.toFixed(1) : '5.0'} ({product.reviews ? product.reviews.length : 0} reviews)
                  </span>
                </div>
              </div>

              {/* Shopping cart trigger inline */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => { onAddToCart(product); }}
                  className="w-full py-3 bg-blue-600 dark:bg-blue-650 hover:bg-blue-700 dark:hover:bg-blue-700 text-white font-bold rounded-xl transition"
                >
                  Purchase Now
                </button>
                <button
                  onClick={() => onToggleWishlist(product)}
                  className={`w-full py-3 border rounded-xl text-center font-semibold text-xs transition ${
                    isInWishlist
                      ? 'bg-rose-550 border-rose-600 text-white bg-rose-600'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:text-slate-300'
                  }`}
                >
                  {isInWishlist ? 'Remove Wishlist' : 'Add Wishlist'}
                </button>
              </div>
            </div>

            {/* Right side: Tabs system breakdown */}
            <div className="md:col-span-7 flex flex-col">
              {/* Tab Nav Selector */}
              <div className="flex border-b border-slate-100 dark:border-slate-800 mb-4 text-xs font-bold uppercase tracking-wider text-slate-400">
                <button
                  onClick={() => setActiveTab('specs')}
                  className={`pb-2.5 px-1 mr-6 transition ${activeTab === 'specs' ? 'border-b-2 border-blue-600 dark:border-blue-400 text-slate-800 dark:text-white' : 'hover:text-slate-600'}`}
                >
                  Specifications
                </button>
                <button
                  onClick={() => setActiveTab('install')}
                  className={`pb-2.5 px-1 mr-6 transition ${activeTab === 'install' ? 'border-b-2 border-blue-600 dark:border-blue-400 text-slate-800 dark:text-white' : 'hover:text-slate-600'}`}
                >
                  Installation Map
                </button>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className={`pb-2.5 px-1 transition ${activeTab === 'reviews' ? 'border-b-2 border-blue-600 dark:border-blue-400 text-slate-800 dark:text-white' : 'hover:text-slate-600'}`}
                >
                  Customer Reviews ({product.reviews ? product.reviews.length : 0})
                </button>
              </div>

              {/* TAB 1: SPECS */}
              {activeTab === 'specs' && (
                <div className="flex-1 flex flex-col gap-4">
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-medium">
                    {product.description}
                  </p>
                  
                  <div className="bg-slate-50 dark:bg-slate-800/30 rounded-xl overflow-hidden border border-slate-100 dark:border-slate-800 grid grid-cols-1 divide-y divide-slate-100 dark:divide-slate-800">
                    {Object.entries(product.specs || {}).map(([key, val]) => (
                      <div key={key} className="flex justify-between p-2.5 text-xs">
                        <span className="font-bold text-slate-400">{key}</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{val}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 2: INSTALL */}
              {activeTab === 'install' && (
                <div className="flex-1 flex flex-col gap-4">
                  <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-xl text-xs flex items-start gap-2.5 text-blue-800 dark:text-blue-400">
                    <ShieldAlert className="w-5 h-5 shrink-0" />
                    <div>
                      <span className="font-bold block">Authorized Technicians Mandatory</span>
                      To maintain linear warranty protections, this commercial grade gear must be hooked up in compliance with standard safety protocols.
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-bold text-xs text-slate-800 dark:text-white uppercase tracking-wider flex items-center gap-1">
                      <Wrench className="w-4 h-4 text-slate-450" />
                      Step-by-step Installation Blueprint
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed font-mono">
                      {product.installationDetails || "Review general technical layout catalogs provided in shipping arrays."}
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 3: REVIEWS */}
              {activeTab === 'reviews' && (
                <div className="flex-1 flex flex-col gap-6">
                  {/* List existing ones */}
                  <div className="space-y-4 max-h-48 overflow-y-auto pr-1">
                    {(!product.reviews || product.reviews.length === 0) ? (
                      <p className="text-xs text-slate-400 italic">No verified reviews submitted yet. Be the first to analyze this component!</p>
                    ) : (
                      product.reviews.map((rev) => (
                        <div key={rev.id} className="bg-slate-50 dark:bg-slate-850 p-3 rounded-lg border border-slate-100 dark:border-slate-800 text-xs shadow-sm">
                          <div className="flex justify-between items-center mb-1">
                            <span className="font-bold text-slate-800 dark:text-slate-250">{rev.user}</span>
                            <span className="text-[10px] text-slate-400 font-mono">{rev.date}</span>
                          </div>
                          <div className="flex items-center gap-0.5 text-yellow-400 mb-2">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} className={`w-3 h-3 ${i < rev.rating ? 'fill-current' : 'text-slate-200'}`} />
                            ))}
                          </div>
                          <p className="text-slate-600 dark:text-slate-350 italic">{rev.comment}</p>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Add Review form */}
                  <form onSubmit={handleSubmitReview} className="bg-slate-50 dark:bg-slate-850 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
                    <h4 className="font-bold text-xs text-slate-800 dark:text-white mb-3 uppercase tracking-wider flex items-center gap-1">
                      <PlusCircle className="w-4 h-4 text-blue-600" />
                      Add Verified Review
                    </h4>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-3">
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Your Full Name</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g. Liam Vance"
                          value={userName}
                          onChange={(e) => setUserName(e.target.value)}
                          className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                        />
                      </div>
                      <div>
                        <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Rating Sizing</label>
                        <select
                          value={rating}
                          onChange={(e) => setRating(parseInt(e.target.value, 10))}
                          className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-bold"
                        >
                          <option value="5">⭐⭐⭐⭐⭐ Excellent Sizing (5/5)</option>
                          <option value="4">⭐⭐⭐⭐ Great Output (4/5)</option>
                          <option value="3">⭐⭐⭐ Standard Yield (3/5)</option>
                          <option value="2">⭐⭐ Underperforming (2/5)</option>
                          <option value="1">⭐ High Failure Rate (1/5)</option>
                        </select>
                      </div>
                    </div>

                    <div className="mb-3">
                      <label className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Verification Review comment</label>
                      <textarea
                        required
                        rows={2}
                        placeholder="State technical performance, efficiency metrics and installation comments..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2 bg-slate-900 hover:bg-slate-850 dark:bg-slate-700 text-white font-bold rounded-lg text-xs tracking-wide transition"
                    >
                      Publish Verification
                    </button>
                  </form>
                </div>
              )}
            </div>

          </div>

          <div className="px-6 py-3 bg-slate-50 dark:bg-slate-950/40 border-t border-slate-100 dark:border-slate-800 text-right">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-200 text-slate-800 dark:bg-slate-800 dark:text-slate-350 text-xs font-semibold rounded-lg transition"
            >
              Exit Specifications panel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
