/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Sun, Video, Calculator, Settings, ShoppingBag, Heart, Search, HelpCircle,
  Menu, X, Shield, Zap, Sparkles, Star, ShoppingCart, ArrowRight, Check,
  BookOpen, Calendar, MapPin, Send, Loader2, ArrowUpRight, CheckCircle2,
  FileText, Download, MessageSquare, PhoneCall, Trash2
} from 'lucide-react';

import { Product, CartItem, Order, QuotationRequest, AnalyticsSummary, CalculatorResult } from './types';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ApplianceCalculator from './components/ApplianceCalculator';
import CctvCompare from './components/CctvCompare';
import ProductDetailsModal from './components/ProductDetailsModal';
import AdminPanel from './components/AdminPanel';

export default function App() {
  // Navigation choices: 'home' | 'solar' | 'cctv' | 'calculator' | 'custom-spec' | 'cart' | 'wishlist' | 'admin'
  const [activeTab, setActiveTab] = useState<string>('home');
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  
  // Custom Filters state
  const [solarFilterCategory, setSolarFilterCategory] = useState<string>('all');
  const [solarFilterBrand, setSolarFilterBrand] = useState<string>('all');
  const [solarFilterPower, setSolarFilterPower] = useState<string>('all');
  
  const [cctvFilterCategory, setCctvFilterCategory] = useState<string>('all');
  const [cctvFilterBrand, setCctvFilterBrand] = useState<string>('all');
  const [cctvFilterResolution, setCctvFilterResolution] = useState<string>('all');

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [darkMode, setDarkMode] = useState<boolean>(false);

  // CCTV Side-by-side spec compare array (max 3 items)
  const [compareIds, setCompareIds] = useState<string[]>([]);
  
  // Modals state
  const [activeProductModal, setActiveProductModal] = useState<Product | null>(null);
  
  // Custom consulting form state
  const [consultName, setConsultName] = useState('');
  const [consultEmail, setConsultEmail] = useState('');
  const [consultPhone, setConsultPhone] = useState('');
  const [consultType, setConsultType] = useState('residential');
  const [consultRooms, setConsultRooms] = useState('4 rooms');
  const [consultBackupHours, setConsultBackupHours] = useState(8);
  const [consultArea, setConsultArea] = useState('Main entrance and backyard');
  const [consultBrand, setConsultBrand] = useState('Aura Solar & SecuriEye');
  const [consultBudget, setConsultBudget] = useState('₦1,500 - ₦3,000');
  const [consultNotes, setConsultNotes] = useState('');
  const [consultSuccessMessage, setConsultSuccessMessage] = useState<string | null>(null);
  const [isConsultLoading, setIsConsultLoading] = useState(false);

  // E-commerce checkout states
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'invoice'>('cart');
  const [buyerName, setBuyerName] = useState('');
  const [buyerEmail, setBuyerEmail] = useState('');
  const [buyerPhone, setBuyerPhone] = useState('');
  const [buyerAddress, setBuyerAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'bank_transfer' | 'delivery_payment' | 'whatsapp_order'>('whatsapp_order');
  const [latestGeneratedOrder, setLatestGeneratedOrder] = useState<Order | null>(null);

  // AI Advisor assistance widget states
  const [aiQuestion, setAiQuestion] = useState<string>('');
  const [aiReplies, setAiReplies] = useState<{ role: 'user' | 'assistant', text: string }[]>([
    { role: 'assistant', text: 'Diagnostics Active. Hello! I am the HeliosGuard smart automation assistant. Ask me questions about sizing lithium storage arrays, camera coverage margins, or which solar panels match your active appliances.' }
  ]);
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // Corporate bookings
  const [bookingDate, setBookingDate] = useState('2026-06-15');
  const [bookingTime, setBookingTime] = useState('10:00');
  const [bookingType, setBookingType] = useState('Solar Sizing Site-Analysis');
  const [bookingConfirmed, setBookingConfirmed] = useState(false);

  // Admin states loaded from backend
  const [orders, setOrders] = useState<Order[]>([]);
  const [quotes, setQuotes] = useState<QuotationRequest[]>([]);
  const [analytics, setAnalytics] = useState<AnalyticsSummary>({
    revenue: 3450,
    completedSolarProjects: 14,
    powerInstalledKw: 48.5,
    happyClients: 89,
    pendingQuotes: 1,
    productsLowStock: 2,
    totalOrdersCount: 2,
    recentOrders: []
  });

  // Load Products and state on Boot
  useEffect(() => {
    fetchProducts();
    fetchOrders();
    fetchQuotes();
    fetchAnalytics();
  }, []);

  // Update dark mode class list
  useEffect(() => {
    const root = window.document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [darkMode]);

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
      }
    } catch (e) {
      console.warn("Failed fetching products from Express backend, utilizing static fallback.", e);
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
      }
    } catch {}
  };

  const fetchQuotes = async () => {
    try {
      const res = await fetch('/api/quotations');
      if (res.ok) {
        const data = await res.json();
        setQuotes(data);
      }
    } catch {}
  };

  const fetchAnalytics = async () => {
    try {
      const res = await fetch('/api/analytics');
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
      }
    } catch {}
  };

  // CART ACTIONS
  const handleAddToCart = (product: Product) => {
    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      setCart(cart.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
  };

  const handleUpdateCartQty = (id: string, newQty: number) => {
    if (newQty <= 0) {
      setCart(cart.filter(item => item.product.id !== id));
    } else {
      setCart(cart.map(item => item.product.id === id ? { ...item, quantity: newQty } : item));
    }
  };

  const handleRemoveFromCart = (id: string) => {
    setCart(cart.filter(item => item.product.id !== id));
  };

  const cartTotal = cart.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);

  // WISHLIST ACTIONS
  const handleToggleWishlist = (product: Product) => {
    const exists = wishlist.some(item => item.id === product.id);
    if (exists) {
      setWishlist(wishlist.filter(item => item.id !== product.id));
    } else {
      setWishlist([...wishlist, product]);
    }
  };

  // COMPARE ACTIONS
  const handleToggleCompare = (id: string) => {
    if (compareIds.includes(id)) {
      setCompareIds(compareIds.filter(item => item !== id));
    } else {
      if (compareIds.length >= 3) {
        // limit reached
        alert("You can compare up to 3 CCTV security systems simultaneously.");
        return;
      }
      setCompareIds([...compareIds, id]);
    }
  };

  // REVIEWS SUBMISSION DYNAMIC
  const handleAddReview = (productId: string, newReview: any) => {
    // update state in front-end products
    setProducts(products.map(p => {
      if (p.id === productId) {
        const updatedReviews = p.reviews ? [...p.reviews, newReview] : [newReview];
        const newRating = updatedReviews.reduce((sum, r) => sum + r.rating, 0) / updatedReviews.length;
        return {
          ...p,
          reviews: updatedReviews,
          rating: Number(newRating.toFixed(1))
        };
      }
      return p;
    }));

    if (activeProductModal && activeProductModal.id === productId) {
      const updatedReviews = activeProductModal.reviews ? [...activeProductModal.reviews, newReview] : [newReview];
      const newRating = updatedReviews.reduce((sum, r) => sum + r.rating, 0) / updatedReviews.length;
      setActiveProductModal({
        ...activeProductModal,
        reviews: updatedReviews,
        rating: Number(newRating.toFixed(1))
      });
    }
  };

  // CHECKOUT COMMIT FLOW
  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!buyerName.trim() || !buyerPhone.trim()) {
      alert("Please specify contact details to file the delivery.");
      return;
    }

    const orderPayload = {
      customerName: buyerName,
      customerEmail: buyerEmail || 'anonymous@helios-buyer.com',
      customerPhone: buyerPhone,
      address: buyerAddress || 'Store Pickup',
      items: cart.map(item => ({
        productId: item.product.id,
        quantity: item.quantity
      })),
      paymentMethod
    };

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });

      if (res.ok) {
        const orderData: Order = await res.json();
        setLatestGeneratedOrder(orderData);
        setOrders([orderData, ...orders]);
        
        // Clear Cart
        setCart([]);
        setCheckoutStep('invoice');
        fetchAnalytics(); // reload stats
      } else {
        const err = await res.json();
        alert(err.error || "Order dispatch failure.");
      }
    } catch {
      // client mock backup if backend is disconnected
      const fallbackOrder: Order = {
        id: `ord-${Math.floor(1000 + Math.random() * 9000)}`,
        customerName: buyerName,
        customerEmail: buyerEmail,
        customerPhone: buyerPhone,
        address: buyerAddress,
        items: cart.map(i => ({ productId: i.product.id, productName: i.product.name, price: i.product.price, quantity: i.quantity })),
        totalPrice: cartTotal,
        paymentMethod,
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      setLatestGeneratedOrder(fallbackOrder);
      setOrders([fallbackOrder, ...orders]);
      setCart([]);
      setCheckoutStep('invoice');
    }
  };

  // WHATSAPP ORDER DESCRIPTOR REDIRECT BUILDER
  const handleTriggerWhatsAppOrder = (order: Order) => {
    const orderText = `*HELIOSGUARD SOLUTIONS ORDER* ☀️🛡️\n\n` +
      `Invoice Ref: *${order.id}*\n` +
      `Client: *${order.customerName}*\n` +
      `Phone: ${order.customerPhone}\n` +
      `Site Delivery Address: ${order.address}\n\n` +
      `*Selected Sized Components list:*\n` +
      order.items.map(i => `- ${i.productName} (Qty: ${i.quantity} units) @ ₦${i.price} ea`).join('\n') +
      `\n\nTotal price rate: *₦${order.totalPrice.toLocaleString()}*\n` +
      `Payment choice context: ${order.paymentMethod.replace('_', ' ').toUpperCase()}\n\n` +
      `_Please verify this project hardware list and dispatch the certified engineer installer team._`;

    const encodedText = encodeURIComponent(orderText);
    window.open(`https://api.whatsapp.com/send?phone=1800435467&text=${encodedText}`, '_blank');
  };

  // CONSULTING SPEC COMMITTING
  const handleConsultSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consultName.trim() || !consultPhone.trim()) {
      alert("Name and phone numbers are verified fields.");
      return;
    }

    setIsConsultLoading(true);
    const consultPayload = {
      customer: {
        name: consultName,
        email: consultEmail,
        phone: consultPhone,
        buildingType: consultType,
        roomsOrOffices: consultRooms,
        backupHours: Number(consultBackupHours),
        securityArea: consultArea,
        preferredBrand: consultBrand,
        budgetRange: consultBudget,
        notes: consultNotes
      }
    };

    try {
      const res = await fetch('/api/quotations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(consultPayload)
      });

      if (res.ok) {
        const data: QuotationRequest = await res.json();
        setQuotes([data, ...quotes]);
        setConsultSuccessMessage(`Consultation Filed Successfully Under Ref: ${data.id}. Our professional energy architects have generated optimal recommendations.`);
        
        // Reset consultation inputs
        setConsultName('');
        setConsultPhone('');
        setConsultEmail('');
        setConsultNotes('');
        setIsConsultLoading(false);
      }
    } catch {
      setIsConsultLoading(false);
      setConsultSuccessMessage("Project scope received. Our engineers will verify system sizing details and dispatch quotation plans directly.");
    }
  };

  // CALCULATOR INTEGRATED QUOTE REQUEST TRIGGER
  const handleCalculatorRequestQuote = async (calcResult: CalculatorResult, appliances: any[]) => {
    const briefNotes = `Formulated via Automated Sizing Calculator. Sized load requirements: ${(calcResult.dailyWh / 1000).toFixed(2)} kWh. Selected appliance list count: ${appliances.length}. Sized hardware includes: ${calcResult.recommendedPanelsNum}x panels and ${(calcResult.recommendedInverterW/1000).toFixed(1)}kW smart inverter.`;
    
    // Auto-prefill consulting tab and swap
    setConsultNotes(briefNotes);
    setConsultBackupHours(calcResult.backupHours);
    setConsultBudget(`₦${calcResult.estimatedCost - 500} - ₦${calcResult.estimatedCost + 800}`);
    setActiveTab('custom-spec');
  };

  // SMART AI PRODUCT ADVICE MESSENGER
  const handleSendAiQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestion.trim()) return;

    const userMsg = aiQuestion;
    setAiQuestion('');
    setAiReplies(prev => [...prev, { role: 'user', text: userMsg }]);
    setIsAiLoading(true);

    try {
      const res = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          cartItems: cart,
          question: userMsg
        })
      });

      if (res.ok) {
        const data = await res.json();
        setAiReplies(prev => [...prev, { role: 'assistant', text: data.recommendation }]);
      } else {
        setAiReplies(prev => [...prev, { role: 'assistant', text: "Advisory channels are active. We highly suggest combining our 5.12kWh lithium storage arrays paired with 550W bifacial solar modules." }]);
      }
    } catch {
      setAiReplies(prev => [...prev, { role: 'assistant', text: "Our server-side AI advisor channels are syncing. Consider pairing our 550W bifacial high-efficiency panels." }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // BOOKING CONTROLS
  const handleBookVisit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingConfirmed(true);
    setTimeout(() => setBookingConfirmed(false), 5000);
  };

  // ADMIN OPERATIONS LINKAGE
  const handleAddProductAdmin = async (newProd: Partial<Product>) => {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProd)
      });
      if (res.ok) {
        fetchProducts();
        fetchAnalytics();
      }
    } catch {}
  };

  const handleEditProductAdmin = async (id: string, updatedFields: Partial<Product>) => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedFields)
      });
      if (res.ok) {
        fetchProducts();
        fetchAnalytics();
      }
    } catch {}
  };

  const handleDeleteProductAdmin = async (id: string) => {
    if (!confirm("Are you sure you want to delete this product?")) return;
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: 'DELETE'
      });
      if (res.ok) {
        fetchProducts();
        fetchAnalytics();
      }
    } catch {}
  };

  const handleChangeOrderStatusAdmin = async (orderId: string, status: Order['status']) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchOrders();
        fetchAnalytics();
      }
    } catch {}
  };

  const handleChangeQuoteStatusAdmin = async (quoteId: string, status: QuotationRequest['status']) => {
    try {
      const res = await fetch(`/api/quotations/${quoteId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        fetchQuotes();
        fetchAnalytics();
      }
    } catch {}
  };

  // FILTERED SOLAR PRODUCTS Computed array
  const filteredSolarProducts = products
    .filter(p => p.category === 'solar')
    .filter(p => solarFilterCategory === 'all' || p.subCategory === solarFilterCategory)
    .filter(p => solarFilterBrand === 'all' || p.brand.toLowerCase() === solarFilterBrand.toLowerCase())
    .filter(p => {
      if (solarFilterPower === 'all') return true;
      const wattsStr = p.specs["Max Power (Pmax)"] || p.specs["Nominal AC Output"] || "";
      const watts = parseInt(wattsStr, 10) || 0;
      if (solarFilterPower === 'high') return watts >= 500;
      if (solarFilterPower === 'med') return watts > 100 && watts < 500;
      if (solarFilterPower === 'low') return watts <= 100 || watts === 0;
      return true;
    })
    .filter(p => searchQuery === '' || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.brand.toLowerCase().includes(searchQuery.toLowerCase()));

  // FILTERED CCTV PRODUCTS Computed array
  const filteredCctvProducts = products
    .filter(p => p.category === 'cctv')
    .filter(p => cctvFilterCategory === 'all' || p.subCategory === cctvFilterCategory)
    .filter(p => cctvFilterBrand === 'all' || p.brand.toLowerCase() === cctvFilterBrand.toLowerCase())
    .filter(p => {
      if (cctvFilterResolution === 'all') return true;
      const desc = p.description.toLowerCase() + JSON.stringify(p.specs).toLowerCase();
      if (cctvFilterResolution === '4k') return desc.includes('4k') || desc.includes('8 megapixel');
      if (cctvFilterResolution === 'color') return desc.includes('color');
      if (cctvFilterResolution === 'wireless') return desc.includes('wireless') || desc.includes('cellular') || desc.includes('4g');
      return true;
    })
    .filter(p => searchQuery === '' || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.brand.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="flex flex-col min-h-screen bg-slate-55 text-slate-900 font-sans dark:bg-slate-950 dark:text-slate-100 transition-colors duration-300" id="helios-root">
      
      {/* Dynamic Header navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cart={cart}
        wishlist={wishlist}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* Main Screen Router layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8" id="application-router-canvas">
        
        {/* TAB 1: LANDING HOMEPAGE */}
        {activeTab === 'home' && (
          <div className="space-y-16" id="view-homepage-landing">
            
            {/* HELIOSGUARD PREMIUM SLEEK HERO BANNER */}
            <section className="relative rounded-3xl bg-slate-900 overflow-hidden flex flex-col justify-center p-8 sm:p-16 border border-slate-800 shadow-2xl min-h-[460px]" id="landing-hero-card">
              <div className="absolute top-0 right-0 w-full sm:w-1/2 h-full opacity-35 select-none pointer-events-none">
                <div className="absolute inset-0 bg-gradient-to-l from-transparent via-slate-900/40 to-slate-900"></div>
                <div className="w-full h-full bg-[repeating-linear-gradient(45deg,#1e293b_0,#1e293b_1px,transparent_0,transparent_50%)] bg-[size:10px_10px]"></div>
              </div>
              
              <div className="relative z-10 max-w-2xl text-left space-y-6">
                <span className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold uppercase tracking-widest rounded-full inline-block italic font-mono transition">
                  ✨ PREMIUM SOLAR POWER & SECURITY TELEMETRY
                </span>
                
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white leading-[1.05] tracking-tight">
                  Powering your home. <br/>
                  <span className="text-blue-500 dark:text-blue-400">Securing your future.</span>
                </h1>
                
                <p className="text-sm sm:text-base text-slate-300 max-w-lg leading-relaxed">
                  We integrate tier-1 high efficiency monocrystalline solar panels with heavy-duty smart inverters and intelligent AI Dome surveillance networks to defend commercial assets and power residential arrays autonomously.
                </p>

                <div className="flex flex-wrap gap-3 pt-4">
                  <button 
                    onClick={() => setActiveTab('solar')}
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition flex items-center gap-1.5"
                  >
                    <span>Shop Solar Products</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setActiveTab('cctv')}
                    className="px-6 py-3 bg-slate-800 hover:bg-slate-750 text-white font-bold rounded-xl text-xs sm:text-sm border border-slate-700 transition"
                  >
                    Explore CCTV Cameras
                  </button>
                  <button 
                    onClick={() => setActiveTab('calculator')}
                    className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs sm:text-sm transition flex items-center gap-1.5"
                  >
                    <Calculator className="w-4 h-4" />
                    <span>Sizing Solar Calculator</span>
                  </button>
                </div>
              </div>
            </section>

            {/* INTRO SERVICES AND BRAND SUMMARY */}
            <section className="grid grid-cols-1 md:grid-cols-3 gap-8" id="corporate-services-intro">
              <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col gap-3">
                <div className="w-10 h-10 bg-sky-100 dark:bg-sky-950/40 rounded-xl flex items-center justify-center text-sky-500">
                  <Sun className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white">Tier-1 Solar Engineering</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Dual-glass bifacial cells capturing front and ambient surface albedo refraction to hike daily peak yields by up to 25%.
                </p>
              </div>

              <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col gap-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-950/40 rounded-xl flex items-center justify-center text-blue-500">
                  <Video className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white">Surveillance Intelligence</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Smart AcuSense object classification networks sorting vehicles or footfalls, removing typical false alert hazards completely.
                </p>
              </div>

              <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-850 shadow-sm flex flex-col gap-3">
                <div className="w-10 h-10 bg-emerald-105 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl flex items-center justify-center text-emerald-500">
                  <Shield className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-bold text-slate-800 dark:text-white">Unified System Integrity</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  Off-grid security arrays backing recording servers via custom sized lithium deep cycle storage for seamless operations all night.
                </p>
              </div>
            </section>

            {/* TRUST METRICS STATS */}
            <section className="bg-blue-600 rounded-3xl p-8 text-white grid grid-cols-2 lg:grid-cols-4 gap-8 text-center shadow-lg relative overflow-hidden" id="operational-stats-bento">
              <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full blur-2xl pointer-events-none"></div>
              
              <div>
                <span className="text-4xl sm:text-5xl font-black font-mono block">2,400+</span>
                <span className="text-xs uppercase tracking-wider font-semibold opacity-85 mt-2 block">Projects Completed</span>
              </div>
              
              <div>
                <span className="text-4xl sm:text-5xl font-black font-mono block">12.5 MW</span>
                <span className="text-xs uppercase tracking-wider font-semibold opacity-85 mt-2 block">Solar Sized Installed</span>
              </div>

              <div>
                <span className="text-4xl sm:text-5xl font-black font-mono block">99.8%</span>
                <span className="text-xs uppercase tracking-wider font-semibold opacity-85 mt-2 block">Security Shield Rating</span>
              </div>

              <div>
                <span className="text-4xl sm:text-5xl font-black font-mono block">90+</span>
                <span className="text-xs uppercase tracking-wider font-semibold opacity-85 mt-2 block">Corporate Happy Clients</span>
              </div>
            </section>

            {/* FEATURED PRODUCTS CAROUSEL SHIFT */}
            <section className="space-y-6" id="landing-featured-components">
              <div className="flex justify-between items-end">
                <div>
                  <h3 className="text-2xl font-black text-slate-800 dark:text-white">Pre-Packaged Core Selections</h3>
                  <p className="text-xs text-slate-400">Our highest rated solar panels, modular LiFePO4 batteries and security gear.</p>
                </div>
                <button 
                  onClick={() => setActiveTab('solar')}
                  className="text-xs font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline"
                >
                  <span>Review full catalog</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.filter(p => p.featured).slice(0, 4).map((p) => (
                  <div key={p.id} className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800/80 flex flex-col justify-between shadow-sm relative group">
                    <span className="absolute top-3 right-3 z-10 p-1.5 rounded-full bg-white/80 dark:bg-slate-800/80 border text-rose-500 cursor-pointer" onClick={() => handleToggleWishlist(p)}>
                      <Heart className={`w-3.5 h-3.5 ${wishlist.some(w => w.id === p.id) ? 'fill-current' : ''}`} />
                    </span>

                    <div>
                      <div className="w-full h-40 bg-slate-100 rounded-xl overflow-hidden mb-3">
                        <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" />
                      </div>
                      <span className="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 rounded text-[9px] font-mono uppercase font-bold tracking-wider">
                        {p.brand}
                      </span>
                      <h4 className="text-xs font-bold text-slate-800 dark:text-white mt-1.5 line-clamp-2 h-8 leading-snug">
                        {p.name}
                      </h4>
                      <p className="text-[11px] text-slate-400 mt-1 line-clamp-2">{p.description}</p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-50 dark:border-slate-800/50 flex items-center justify-between">
                      <span className="text-sm font-black font-mono text-blue-600 dark:text-blue-400">₦{p.price}</span>
                      <div className="flex gap-1.5">
                        <button 
                          onClick={() => setActiveProductModal(p)}
                          className="px-2 py-1 text-[10px] bg-slate-50 hover:bg-slate-150 border dark:border-slate-705 dark:text-slate-350 dark:bg-slate-800 rounded font-medium"
                        >
                          Specs
                        </button>
                        <button 
                          onClick={() => handleAddToCart(p)}
                          className="px-2.5 py-1 text-[10px] bg-slate-950 text-white dark:bg-blue-600 dark:text-white font-bold rounded transition"
                        >
                          + Buy
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* TRUSTED PARTNER LOGOS BAR */}
            <section className="py-6 border-t border-b border-slate-100 dark:border-slate-800 text-center" id="corporate-partners-bar">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-4">TECHNOLOGICAL HARDWARE INTEGRATION LEADERS</span>
              <div className="flex flex-wrap justify-center items-center gap-8 sm:gap-16 opacity-50 grayscale hover:grayscale-0 transition duration-350">
                <span className="text-sm font-sans font-black tracking-tight text-slate-500 dark:text-slate-300">☀️ HIKVISION SEC</span>
                <span className="text-sm font-sans font-black tracking-tight text-slate-500 dark:text-slate-300">⚡ VICTRON ENERGY</span>
                <span className="text-sm font-sans font-black tracking-tight text-slate-500 dark:text-slate-300">🔋 LI-FBP TECH</span>
                <span className="text-sm font-sans font-black tracking-tight text-slate-500 dark:text-slate-300">🔷 SUNSYNK COMP</span>
                <span className="text-sm font-sans font-black tracking-tight text-slate-500 dark:text-slate-300">📦 WESTERN SURVEYS</span>
              </div>
            </section>

            {/* ADVISORY SERVICE SITE-BOOK VISIT OR AI CHAT BENTO GRID */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="support-and-bookings-bento">
              
              {/* Site Consultation Booking form */}
              <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-850">
                <h3 className="text-lg font-bold text-slate-800 dark:text-white flex items-center gap-1.5 mb-2">
                  <Calendar className="w-5 h-5 text-blue-600" />
                  Request Engineer Site Booking
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mb-6">
                  Select a date context and our physical system team will visit your residential/commercial site for physical sizing checks.
                </p>

                <form onSubmit={handleBookVisit} className="space-y-4 text-xs font-semibold">
                  <div>
                    <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Select Consultation Type</label>
                    <select 
                      value={bookingType}
                      onChange={(e) => setBookingType(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-white"
                    >
                      <option value="Solar Sizing Site-Analysis">☀️ Photovoltaic Array Sizing Analysis</option>
                      <option value="CCTV Security Boundary check">🛡️ CCTV Placement Boundary survey</option>
                      <option value="Full Facility Hybrid Grid Sizing">⚡ Combined Off-Grid power Consultation</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Target Date</label>
                      <input 
                        type="date"
                        value={bookingDate}
                        onChange={(e) => setBookingDate(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-mono font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Target Time Window</label>
                      <input 
                        type="time"
                        value={bookingTime}
                        onChange={(e) => setBookingTime(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-bold"
                      />
                    </div>
                  </div>

                  {bookingConfirmed ? (
                    <div className="p-3 bg-emerald-500/15 rounded-lg border border-emerald-500/25 text-xs text-emerald-800 dark:text-emerald-400 text-center font-bold">
                      ✅ Visit Sizing Confirmed! We Scheduled: {bookingDate} @ {bookingTime}
                    </div>
                  ) : (
                    <button 
                      type="submit"
                      className="w-full py-3 bg-slate-900 border hover:bg-slate-800 dark:bg-slate-850 dark:hover:bg-slate-800 text-white font-bold rounded-xl transition-colors text-center"
                    >
                      Process Sizing Visit Reservation
                    </button>
                  )}
                </form>
              </div>

              {/* Collapsible Frequently Asked Questions (FAQ) block */}
              <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-200 dark:border-slate-850 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-800 dark:text-white mb-4">Sizing FAQ Guidance Desk</h3>
                  <div className="space-y-4 text-xs">
                    <div className="p-3 bg-slate-50 dark:bg-slate-850/40 rounded-lg border">
                      <span className="font-extrabold text-slate-800 dark:text-white block mb-1">Q: How many solar panels are required for an office air conditioner load?</span>
                      <p className="text-slate-500 leading-relaxed">
                        A typical 1.5 HP inverter AC pulls around 1,200W constantly. Sizing an 8-hour continuous cycle demands approx 9.6 kWh, which recommends a minimum of 6x 550W Aure-Bifacial solar modules.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 dark:bg-slate-850/40 rounded-lg border">
                      <span className="font-extrabold text-slate-800 dark:text-white block mb-1">Q: Why prefer POE (Power over Ethernet) cameras over typical WIFI setups?</span>
                      <p className="text-slate-500 leading-relaxed">
                        POE handles both 4K high fidelity video payloads and continuous power feeds flatly through a single copper cable from the NVR, removing wireless signal dropouts entirely.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-805 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
                  <span className="text-slate-400 font-semibold font-mono">Need custom engineering answers directly?</span>
                  <button 
                    onClick={() => setActiveTab('custom-spec')}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-sm"
                  >
                    Contact Consulting Desk
                  </button>
                </div>
              </div>

            </section>

          </div>
        )}

        {/* TAB 2: SOLAR PRODUCTS PAGE */}
        {activeTab === 'solar' && (
          <div className="space-y-8" id="view-solar-catalog">
            
            {/* Page Header */}
            <div>
              <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest font-mono">Energy Independence</span>
              <h2 className="text-3xl font-black text-slate-800 dark:text-white mt-1">Solar PV Components Catalog</h2>
              <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
                Configure your solar system arrays using our certified monocrystalline panels, hybrid synk inverters, LiFePO4 batteries, and heavy duty MC4 connectors.
              </p>
            </div>

            {/* Filter controls */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap gap-4 items-center justify-between text-xs" id="solar-catalog-filter-bar">
              <div className="flex flex-wrap gap-3 items-center">
                {/* Category filters */}
                <div className="flex flex-wrap bg-slate-50 dark:bg-slate-850 p-1 rounded-lg border">
                  {[
                    { id: 'all', label: 'All Equipment' },
                    { id: 'panels', label: 'Solar Panels' },
                    { id: 'inverters', label: 'Smart Inverters' },
                    { id: 'batteries', label: 'LiFePO4 Storage' },
                    { id: 'accessories', label: 'Grid cables & parts' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSolarFilterCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-md font-semibold transition ${solarFilterCategory === cat.id ? 'bg-white dark:bg-slate-700 text-slate-850 dark:text-white shadow-xs' : 'text-slate-450 hover:text-slate-800'}`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Brand selection dropdown */}
                <select
                  value={solarFilterBrand}
                  onChange={(e) => setSolarFilterBrand(e.target.value)}
                  className="p-2 py-1.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-705"
                >
                  <option value="all">Any Brands</option>
                  <option value="Aura Solar">Aura Solar line</option>
                  <option value="Sunsynk">Sunsynk Hybrid</option>
                  <option value="VoltGuard">VoltGuard Battery</option>
                  <option value="Victron Energy">Victron Energy Ltd</option>
                </select>

                {/* Power Output thresholds */}
                <select
                  value={solarFilterPower}
                  onChange={(e) => setSolarFilterPower(e.target.value)}
                  className="p-2 py-1.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-705"
                >
                  <option value="all">Sized Watts Output: All</option>
                  <option value="high">High Yield (Pmax &gt;= 500W)</option>
                  <option value="med">Medium Sized (Load 100W - 499W)</option>
                  <option value="low">Modular auxiliary (Loads &lt; 100W)</option>
                </select>
              </div>

              {/* Status active details readout */}
              <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded">
                Yielded {filteredSolarProducts.length} components
              </span>
            </div>

            {/* Products grid */}
            {filteredSolarProducts.length === 0 ? (
              <div className="text-center py-12 text-slate-400 font-medium">No solar products match selected criteria query.</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="solar-products-grid">
                {filteredSolarProducts.map((p) => {
                  const hasStock = p.stock > 0;
                  return (
                    <div key={p.id} className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-250 dark:border-slate-800/80 flex flex-col justify-between shadow-xs group relative">
                      
                      {/* Wishlist triggers */}
                      <button 
                        onClick={() => handleToggleWishlist(p)}
                        className={`absolute top-4 right-4 z-10 p-2 rounded-full border bg-white/95 dark:bg-slate-800 shadow-sm transition ${wishlist.some(w => w.id === p.id) ? 'text-rose-500' : 'text-slate-405 hover:text-rose-400'}`}
                      >
                        <Heart className={`w-4 h-4 ${wishlist.some(w => w.id === p.id) ? 'fill-current' : ''}`} />
                      </button>

                      <div>
                        {/* Thumb frame */}
                        <div className="w-full h-44 bg-slate-100 rounded-2xl overflow-hidden mb-4 relative">
                          <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-103 transition duration-300" />
                          <span className={`absolute top-3 left-3 px-2 py-0.5 text-[9px] font-bold text-white uppercase rounded ${p.stock < 12 ? 'bg-blue-600' : 'bg-slate-900/60'}`}>
                            {p.stock} units left
                          </span>
                        </div>

                        {/* Tech tags */}
                        <span className="px-2 py-0.5 bg-slate-50 dark:bg-slate-850/50 text-[10px] text-slate-405 uppercase font-bold rounded">
                          {p.brand}
                        </span>

                        <h3 className="font-extrabold text-sm text-slate-800 dark:text-white mt-2 leading-snug line-clamp-2 h-10 hover:text-blue-600 cursor-pointer" onClick={() => setActiveProductModal(p)}>
                          {p.name}
                        </h3>

                        <p className="text-[11px] text-slate-500 leading-relaxed line-clamp-2 mt-1 italic">
                          "{p.description}"
                        </p>

                        {/* Bullet indicators */}
                        <div className="grid grid-cols-2 gap-1.5 mt-3 pt-3 border-t border-slate-50 dark:border-slate-800 text-[10px] text-slate-450 uppercase font-mono">
                          {Object.entries(p.specs || {}).slice(0, 2).map(([key, val]) => (
                            <div key={key} className="truncate">
                              <span className="block font-bold text-slate-400">{key}</span>
                              <span className="font-semibold text-slate-700 dark:text-slate-205">{val}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="mt-6 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 uppercase font-bold block">Cash rate:</span>
                          <span className="text-base font-black font-mono text-blue-600 dark:text-blue-400">₦{p.price}</span>
                        </div>
                        
                        <div className="flex gap-2">
                          <button
                            onClick={() => setActiveProductModal(p)}
                            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-650 dark:text-slate-300 rounded-xl text-xs font-semibold"
                          >
                            Details
                          </button>
                          <button
                            onClick={() => { handleAddToCart(p); }}
                            className="px-4 py-2 bg-slate-950 hover:bg-slate-900 border dark:border-slate-705 dark:bg-blue-600 dark:hover:bg-blue-700 text-white dark:text-white font-bold rounded-xl text-xs"
                          >
                            + Buy
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: AUTOMATED POWER CALCULATOR TAB */}
        {activeTab === 'calculator' && (
          <div className="space-y-8" id="view-calculator-screen">
            <div className="bg-slate-900 rounded-3xl p-8 text-white relative overflow-hidden border border-slate-800">
              <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-xs font-bold uppercase tracking-widest rounded-full inline-block italic font-mono mb-4">
                ⚙️ MULTI-PHASE SIZING ENGINEERING ALGORITHMS
              </span>
              <h2 className="text-3xl font-black tracking-tight mb-2">Automated Solar Power Calculator Sizer</h2>
              <p className="text-xs text-slate-350 max-w-xl leading-relaxed">
                Add your active home appliances, lights, ventilation or office equipment. Adjust parameters, and our system computes required inverter kW, necessary deep-cycle storage, panel count and estimated hardware expenses instantly.
              </p>
            </div>

            {/* Embed the self contained ApplianceCalculator */}
            <ApplianceCalculator onRequestQuote={handleCalculatorRequestQuote} />
          </div>
        )}

        {/* TAB 4: CCTV SURVEILLANCE PRODUCTS */}
        {activeTab === 'cctv' && (
          <div className="space-y-8" id="view-cctv-catalog">
            
            {/* CCTV Catalog Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
              <div>
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest font-mono">Secured Facilities</span>
                <h2 className="text-3xl font-black text-slate-800 dark:text-white mt-1">CCTV Components & Solar Cameras</h2>
                <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
                  Browse our certified high definition NVR arrays, cellular standard wireless PTZ arrays, Western surveillance internal hard drives and video doorbells.
                </p>
              </div>

              {/* Compare Shelf toggle indicator context */}
              {compareIds.length > 0 && (
                <button 
                  onClick={() => {
                    // Quick jump anchor down
                    const item = document.getElementById('cctv-compare-anchor-card');
                    if (item) item.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Review Competitors Compare ({compareIds.length})</span>
                </button>
              )}
            </div>

            {/* Filter controls */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap gap-4 items-center justify-between text-xs" id="cctv-filter-block">
              <div className="flex flex-wrap gap-3 items-center">
                
                {/* Category selectors */}
                <div className="flex flex-wrap bg-slate-50 dark:bg-slate-850 p-1 rounded-lg border">
                  {[
                    { id: 'all', label: 'All Surveillance' },
                    { id: 'cameras', label: 'Security Cameras' },
                    { id: 'dvrs', label: 'DVR/NVR systems' },
                    { id: 'accessories', label: 'Cables & HDDs' }
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setCctvFilterCategory(cat.id)}
                      className={`px-3 py-1.5 rounded-md font-semibold transition ${cctvFilterCategory === cat.id ? 'bg-white dark:bg-slate-750 text-slate-800' : 'text-slate-405 hover:text-slate-800'}`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                {/* Brands selection */}
                <select
                  value={cctvFilterBrand}
                  onChange={(e) => setCctvFilterBrand(e.target.value)}
                  className="p-2 py-1.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-705"
                >
                  <option value="all">Any Security Brand</option>
                  <option value="SecuriEye">SecuriEye Inc</option>
                  <option value="EagleEye">EagleEye Systems</option>
                  <option value="ProGuard Security">ProGuard Security Ltd</option>
                  <option value="Western Digital">Western Digital (WD)</option>
                </select>

                {/* Intelligent custom filters */}
                <select
                  value={cctvFilterResolution}
                  onChange={(e) => setCctvFilterResolution(e.target.value)}
                  className="p-2 py-1.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-semibold text-slate-705"
                >
                  <option value="all">Sized Specifications: All</option>
                  <option value="4k">4K High-Res Feeds (8MP)</option>
                  <option value="wireless">Off-Grid (4G Cellular / Solar)</option>
                  <option value="color">Full-Color Nightvision</option>
                </select>
              </div>

              <span className="text-[10px] font-mono font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded">
                Yielded {filteredCctvProducts.length} surveillance units
              </span>
            </div>

            {/* Products grid */}
            {filteredCctvProducts.length === 0 ? (
              <div className="text-center py-12 text-slate-400 font-medium">No CCTV cameras match selected filters query.</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" id="cctv-products-grid">
                {filteredCctvProducts.map((p) => {
                  const isComparingThis = compareIds.includes(p.id);
                  return (
                    <div key={p.id} className="bg-white dark:bg-slate-900 rounded-3xl p-5 border border-slate-250 dark:border-slate-800/80 flex flex-col justify-between shadow-xs group relative">
                      
                      {/* Wishlist button */}
                      <button 
                        onClick={() => handleToggleWishlist(p)}
                        className={`absolute top-4 right-4 z-10 p-2 rounded-full border bg-white shadow-xs transition ${wishlist.some(w => w.id === p.id) ? 'text-rose-550' : 'text-slate-405'}`}
                      >
                        <Heart className={`w-4 h-4 ${wishlist.some(w => w.id === p.id) ? 'fill-current' : ''}`} />
                      </button>

                      {/* Side-by-side compare checkbox launcher */}
                      <button 
                        onClick={() => handleToggleCompare(p.id)}
                        className={`absolute top-4 left-4 z-10 px-2 py-1 rounded-md text-[9px] font-bold uppercase transition flex items-center gap-1 border shadow-xs ${isComparingThis ? 'bg-blue-600 text-white border-blue-600' : 'bg-slate-900/80 text-white border-transparent'}`}
                      >
                        {isComparingThis ? 'Compare Active' : '+ Compare Spec'}
                      </button>

                      <div>
                        {/* Thumb image frame */}
                        <div className="w-full h-44 bg-slate-100 rounded-2xl overflow-hidden mb-4 relative">
                          <img src={p.imageUrl} alt={p.name} className="w-full h-full object-cover group-hover:scale-101 transition duration-300" />
                          <span className="absolute bottom-3 left-3 px-2 py-0.5 text-[9px] font-bold text-white uppercase rounded bg-slate-900/60 font-mono">
                            Warranty: {p.warranty.split(',')[0]}
                          </span>
                        </div>

                        {/* Tech tags */}
                        <span className="px-2 py-0.5 bg-slate-50 dark:bg-slate-850/50 text-[10px] text-slate-405 uppercase font-bold rounded">
                          {p.brand}
                        </span>

                        <h3 className="font-extrabold text-sm text-slate-800 dark:text-white mt-1.5 leading-snug line-clamp-2 h-10 hover:text-blue-600 cursor-pointer" onClick={() => setActiveProductModal(p)}>
                          {p.name}
                        </h3>

                        <p className="text-[11px] text-slate-500 leading-relaxed line-clamp-2 mt-1 italic">
                          "{p.description}"
                        </p>

                        {/* Bullet indicators */}
                        <div className="grid grid-cols-2 gap-1.5 mt-3 pt-3 border-t border-slate-50 dark:border-slate-800 text-[10px] text-slate-450 uppercase font-mono">
                          {Object.entries(p.specs || {}).slice(0, 2).map(([key, val]) => (
                            <div key={key} className="truncate">
                              <span className="block font-bold text-slate-405">{key}</span>
                              <span className="font-semibold text-slate-700 dark:text-slate-205">{val}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="mt-6 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] text-slate-400 block uppercase font-bold">Cash rate:</span>
                          <span className="text-base font-black font-mono text-blue-600 dark:text-blue-400">₦{p.price}</span>
                        </div>
                        
                        <div className="flex gap-2">
                          <button
                            onClick={() => setActiveProductModal(p)}
                            className="px-3 py-2 bg-slate-50 hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-650 dark:text-slate-300 rounded-xl text-xs font-semibold"
                          >
                            Details
                          </button>
                          <button
                            onClick={() => { handleAddToCart(p); }}
                            className="px-4 py-2 bg-slate-950 hover:bg-slate-900 border dark:border-slate-705 dark:bg-blue-600 dark:hover:bg-blue-700 text-white dark:text-white font-bold rounded-xl text-xs"
                          >
                            + Buy
                          </button>
                        </div>
                      </div>

                    </div>
                  );
                })}
              </div>
            )}

            {/* CCTV Comparison arena anchored card */}
            <div className="pt-12" id="cctv-compare-anchor-card">
              <CctvCompare
                compareProducts={products.filter(p => compareIds.includes(p.id))}
                onRemoveFromCompare={(id) => setCompareIds(compareIds.filter(item => item !== id))}
                onAddToCart={handleAddToCart}
              />
            </div>

          </div>
        )}

        {/* TAB 5: CUSTOM TECHNICAL REQUEST CONSULTATION TAB */}
        {activeTab === 'custom-spec' && (
          <div className="space-y-8 animate-fadeIn" id="view-custom-consultation">
            
            {/* Header board */}
            <div className="bg-slate-900 rounded-3xl p-8 text-white border border-slate-805 shadow shadow-indigo-950/20 max-w-4xl mx-auto">
              <span className="px-3 py-1 bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-bold uppercase tracking-widest rounded-full inline-block mb-4 font-mono">
                📞 EXPERT SYSTEM ARCHITECTURE CONSULTATION DESK
              </span>
              <h2 className="text-3xl font-black mb-2 tracking-tight">Custom System Sizing & AI Analysis Request</h2>
              <p className="text-xs text-slate-350 max-w-xl leading-relaxed">
                Provide details about your corporate facility workspace size, desired blackout backup hours, outdoor security coverage parameters, and budget. Our Gemini AI system produces customized recommendations and sends requests directly to design technicians.
              </p>
            </div>

            {consultSuccessMessage && (
              <div className="mx-auto max-w-4xl p-5 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 text-emerald-800 dark:text-emerald-400 rounded-2xl text-xs font-semibold">
                <span className="font-extrabold text-sm block mb-1">✅ Project Sizing Request Documented!</span>
                <p className="leading-relaxed whitespace-pre-line">{consultSuccessMessage}</p>
                <button 
                  onClick={() => setConsultSuccessMessage(null)}
                  className="mt-3 px-3 py-1 bg-emerald-600 text-white font-bold rounded"
                >
                  Acknowledged
                </button>
              </div>
            )}

            {/* Sizing Consulting Form layout */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 max-w-4xl mx-auto items-start">
              
              {/* Sizing inputs */}
              <div className="md:col-span-8 bg-white dark:bg-slate-900 rounded-3xl p-6 border border-slate-205 dark:border-slate-800 shadow-sm">
                <h3 className="text-base font-bold text-slate-850 dark:text-white mb-4">Target Project Scope Specifications</h3>
                
                <form onSubmit={handleConsultSubmit} className="space-y-4 text-xs font-semibold">
                  
                  {/* Contact Info box */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-405 uppercase tracking-wider block mb-1">Company Contact Name</label>
                      <input 
                        type="text"
                        required
                        placeholder="Marcus Aurelius"
                        value={consultName}
                        onChange={(e) => setConsultName(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Work Email</label>
                      <input 
                        type="email"
                        required
                        placeholder="marcus@rome.org"
                        value={consultEmail}
                        onChange={(e) => setConsultEmail(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Verified Phone Line</label>
                      <input 
                        type="text"
                        required
                        placeholder="+39 06 123456"
                        value={consultPhone}
                        onChange={(e) => setConsultPhone(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    </div>
                  </div>

                  {/* Sizing constraints */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Building/Facility Type</label>
                      <select 
                        value={consultType}
                        onChange={(e) => setConsultType(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      >
                        <option value="residential">🏡 Premium Residential Villa</option>
                        <option value="commercial">🏢 Multi-story Corporate Office</option>
                        <option value="industrial">🏭 Heavy Industrial Sized Warehouse</option>
                        <option value="offgrid">⛺ Remote Agricultural Farm Site</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Rooms/Offices context magnitude</label>
                      <input 
                        type="text"
                        placeholder="e.g. 15 rooms, 4 warehouse floors"
                        value={consultRooms}
                        onChange={(e) => setConsultRooms(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Target Blackout Autonomy (Hours)</label>
                      <select 
                        value={consultBackupHours}
                        onChange={(e) => setConsultBackupHours(Number(e.target.value))}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      >
                        <option value="4">4 Hours (Emergency coverage)</option>
                        <option value="8">8 Hours (Full office day backup)</option>
                        <option value="12">12 Hours (Commercial night coverage)</option>
                        <option value="24">24 Hours (Seamless Off-Grid autonomy)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Equipment Budget Sizing Allocation</label>
                      <select 
                        value={consultBudget}
                        onChange={(e) => setConsultBudget(e.target.value)}
                        className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                      >
                        <option value="₦1,500 - ₦3,000">Economy Array (₦1,500 - ₦3,000)</option>
                        <option value="₦3,000 - ₦6,000">Mid-tier Professional (₦3,000 - ₦6,000)</option>
                        <option value="₦6,000 - ₦12,000">Heavy Industrial Grade (₦6,000 - ₦12,000)</option>
                        <option value="Above ₦12,000">Vanguard custom (Above ₦12,050)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">CCTV Security Coverage Sizing Requirements</label>
                    <input 
                      type="text"
                      placeholder="e.g. 8x 4K outdoor bullet dome cameras blocking side alleys and front entrance gate"
                      value={consultArea}
                      onChange={(e) => setConsultArea(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-450 uppercase tracking-wider block mb-1">Brief Project Notes (Appliance Load list or structural requests)</label>
                    <textarea 
                      rows={4}
                      placeholder="Input custom structural parameters (e.g. slate roof angle, server rack locations)..."
                      value={consultNotes}
                      onChange={(e) => setConsultNotes(e.target.value)}
                      className="w-full p-2.5 bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 rounded-lg resize-none"
                    />
                  </div>

                  {/* Drag and Drop Upload emulator */}
                  <div className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-2xl p-6 text-center bg-slate-50 dark:bg-slate-850/50">
                    <Settings className="w-8 h-8 text-slate-350 mx-auto mb-2" />
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block">Sized Electrical Draft/Blueprints Portal</span>
                    <span className="text-[10px] text-slate-405 mt-1 block">Drag and drop site images or PDF structural plans here (Optional)</span>
                    <button type="button" className="mt-3 px-3 py-1 bg-white dark:bg-slate-800 border text-[10px] font-semibold rounded hover:bg-slate-100 text-slate-700">Browse folders</button>
                  </div>

                  <button 
                    type="submit"
                    disabled={isConsultLoading}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-705 text-white font-bold rounded-2xl shadow transition flex items-center justify-center gap-2"
                  >
                    {isConsultLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-white" />
                        <span>Sizing Solar with Heuristic AI Advice...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Commit Project Scope Proposal</span>
                      </>
                    )}
                  </button>

                </form>
              </div>

              {/* Consultation sidebar specs */}
              <div className="md:col-span-4 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-900 border border-blue-100/50 dark:border-slate-800 rounded-3xl p-6">
                <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest font-mono block">Direct Engineering desk</span>
                <h4 className="text-sm font-black text-slate-850 dark:text-white mt-1">Guarantees & Installation Promises</h4>
                
                <div className="space-y-4 mt-6 text-xs leading-relaxed text-slate-655 text-slate-600 dark:text-slate-300 font-medium">
                  <div className="flex gap-2">
                    <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <span><b>24-Hour AI Response:</b> Get custom technical assessments with specific hardware items.</span>
                  </div>
                  <div className="flex gap-2">
                    <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <span><b>Site visits:</b> Physical site checks scheduled next week by high-voltage technicians.</span>
                  </div>
                  <div className="flex gap-2">
                    <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                    <span><b>Certified gear:</b> High precision, weather-rated dual-glass mono cells featuring 25-yr warranties.</span>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-blue-105 border-blue-200/50 dark:border-slate-800 text-xs">
                  <span className="text-[10px] text-slate-400 font-mono uppercase block">EMERGENCY OPERATIONS LINE:</span>
                  <a href="tel:1800435467" className="text-sm font-black text-blue-600 dark:text-blue-400 hover:underline">1-800-HELIOS</a>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB 6: SHOPPING CART & SECURE CHECKOUT PAGE */}
        {activeTab === 'cart' && (
          <div className="space-y-8" id="view-shopping-cart-checkout">
            
            <div className="border-b border-slate-100 dark:border-slate-800 pb-4">
              <span className="text-[10px] font-bold text-blue-600 uppercase font-mono tracking-widest">E-Commerce dispatch</span>
              <h2 className="text-3xl font-black text-slate-850 dark:text-white">Active Order Dispatch Portal</h2>
            </div>

            {/* Check steps selection */}
            {cart.length === 0 && checkoutStep === 'cart' ? (
              <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-3xl border p-8" id="cart-workspace-empty">
                <ShoppingCart className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                <h3 className="text-sm font-bold text-slate-700">Your shopping allocation cart is currently empty</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                  Browse our high efficiency Solar components or physical CCTV safety cams/DVR arrays and add hardware elements to continue.
                </p>
                <div className="flex justify-center gap-3 mt-6">
                  <button onClick={() => setActiveTab('solar')} className="px-5 py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl">Shop Solar Array</button>
                  <button onClick={() => setActiveTab('cctv')} className="px-5 py-2.5 bg-slate-200 text-slate-800 text-xs font-bold rounded-xl">Explore Surveillance</button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Check Flow main container LEFT */}
                <div className="lg:col-span-8 flex flex-col gap-6">
                  
                  {/* STEP 1: CART LIST */}
                  {checkoutStep === 'cart' && (
                    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border shadow-xs space-y-4">
                      <h3 className="text-base font-bold text-slate-850 dark:text-white">1. Verified Hardware List</h3>
                      
                      <div className="divide-y divide-slate-100 dark:divide-slate-800">
                        {cart.map((item) => (
                          <div key={item.product.id} className="py-4 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs">
                            <div className="flex items-center gap-3 self-start sm:self-auto">
                              <img src={item.product.imageUrl} alt={item.product.name} className="w-12 h-12 rounded-lg object-cover border" />
                              <div>
                                <h4 className="font-bold text-slate-800 dark:text-white line-clamp-1">{item.product.name}</h4>
                                <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider font-bold">{item.product.brand} • ₦{item.product.price} ea</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-4 self-end sm:self-auto">
                              {/* Qty incrementors */}
                              <div className="flex items-center gap-1.5 border dark:border-slate-700 rounded-lg p-1 bg-slate-50 dark:bg-slate-850">
                                <button onClick={() => handleUpdateCartQty(item.product.id, item.quantity - 1)} className="px-2 py-0.5 font-bold hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 rounded">-</button>
                                <span className="px-2 font-black font-mono text-slate-800 dark:text-white">{item.quantity}</span>
                                <button onClick={() => handleUpdateCartQty(item.product.id, item.quantity + 1)} className="px-2 py-0.5 font-bold hover:bg-slate-200 dark:hover:bg-slate-800 text-slate-600 rounded">+</button>
                              </div>

                              <span className="text-xs font-magenta font-black text-slate-800 dark:text-white font-mono">₦{item.product.price * item.quantity}</span>
                              <button onClick={() => handleRemoveFromCart(item.product.id)} className="text-slate-405 hover:text-rose-600 p-1">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-between items-center text-xs font-bold">
                        <span className="text-slate-400">Cart Sized items total:</span>
                        <span className="text-lg font-black text-blue-600 font-mono">₦{cartTotal.toLocaleString()}</span>
                      </div>

                      <button 
                        onClick={() => setCheckoutStep('shipping')}
                        className="w-full py-4 bg-slate-905 bg-slate-900 text-white font-bold rounded-2xl flex items-center justify-center gap-1 hover:bg-slate-800 tracking-wider transition"
                      >
                        <span>Proceed to Shipping Delivery Setup</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  {/* STEP 2: SHIPPING CONFIGURATION & PAYMENT CHOICE */}
                  {checkoutStep === 'shipping' && (
                    <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 border shadow-xs">
                      <h3 className="text-base font-bold text-slate-850 dark:text-white mb-6">2. Sized Facility Dispatch & Delivery Sizing</h3>
                      
                      <form onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs font-semibold">
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Company / Buyer Full Name</label>
                            <input 
                              type="text"
                              required
                              placeholder="Marcus Aurelius"
                              value={buyerName}
                              onChange={(e) => setBuyerName(e.target.value)}
                              className="w-full p-2.5 bg-slate-50 border dark:bg-slate-800 dark:border-slate-700 rounded-lg"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Primary Verified Phone Line</label>
                            <input 
                              type="text"
                              required
                              placeholder="+39 06 123456"
                              value={buyerPhone}
                              onChange={(e) => setBuyerPhone(e.target.value)}
                              className="w-full p-2.5 bg-slate-50 border dark:bg-slate-800 dark:border-slate-700 rounded-lg text-slate-800 font-mono"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">Billing & Delivery Work Email (Optional)</label>
                          <input 
                            type="email"
                            placeholder="marcus@rome.org"
                            value={buyerEmail}
                            onChange={(e) => setBuyerEmail(e.target.value)}
                            className="w-full p-2.5 bg-slate-50 border dark:bg-slate-800 dark:border-slate-700 rounded-lg"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-slate-405 uppercase block mb-1">Physical Delivery Site Address (For Sized Engineers)</label>
                          <input 
                            type="text"
                            required
                            placeholder="e.g. 742 Evergreen Terrace, building 4B, Springfield"
                            value={buyerAddress}
                            onChange={(e) => setBuyerAddress(e.target.value)}
                            className="w-full p-2.5 bg-slate-50 border dark:bg-slate-850 dark:border-slate-700 rounded-lg"
                          />
                        </div>

                        {/* Multiple Payment gateways selections */}
                        <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80">
                          <label className="text-[10px] font-bold text-slate-450 uppercase block mb-3">Enterprise Secure Payment Gateways</label>
                          
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div 
                              onClick={() => setPaymentMethod('whatsapp_order')}
                              className={`p-4 border rounded-2xl cursor-pointer transition text-center ${paymentMethod === 'whatsapp_order' ? 'border-blue-600 bg-blue-500/10' : 'border-slate-200 dark:border-slate-700'}`}
                            >
                              <span className="font-extrabold text-xs block text-slate-800 dark:text-white">🟢 WhatsApp Order</span>
                              <p className="text-[10px] text-slate-450 mt-1">Book directly, pay on delivery verified</p>
                            </div>

                            <div 
                              onClick={() => setPaymentMethod('bank_transfer')}
                              className={`p-4 border rounded-2xl cursor-pointer transition text-center ${paymentMethod === 'bank_transfer' ? 'border-blue-600 bg-blue-500/10' : 'border-slate-200 dark:border-slate-700'}`}
                            >
                              <span className="font-extrabold text-xs block text-slate-800 dark:text-white">🏦 Bank Transfer</span>
                              <p className="text-[10px] text-slate-450 mt-1">Dispatches swift commercial PDF invoice</p>
                            </div>

                            <div 
                              onClick={() => setPaymentMethod('delivery_payment')}
                              className={`p-4 border rounded-2xl cursor-pointer transition text-center ${paymentMethod === 'delivery_payment' ? 'border-blue-600 bg-blue-500/10' : 'border-slate-200 dark:border-slate-700'}`}
                            >
                              <span className="font-extrabold text-xs block text-slate-800 dark:text-white">📦 Pay on Delivery</span>
                              <p className="text-[10px] text-slate-450 mt-1">Requires certified engineer setup check</p>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-4 pt-4 border-t border-slate-100">
                          <button 
                            type="button"
                            onClick={() => setCheckoutStep('cart')}
                            className="px-4 py-3 bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-350 rounded-xl hover:bg-slate-200"
                          >
                            Back
                          </button>
                          <button 
                            type="submit"
                            className="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md text-center inline-block"
                          >
                            Commit Order Generation
                          </button>
                        </div>

                      </form>
                    </div>
                  )}

                  {/* STEP 3: ORDER INVOICE DOWNLOAD & PRINT */}
                  {checkoutStep === 'invoice' && latestGeneratedOrder && (
                    <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-200 dark:border-slate-800 shadow-xl space-y-6 text-xs text-slate-700 dark:text-slate-300" id="print-invoice-bill-canvas">
                      
                      {/* Logo and code header */}
                      <div className="flex justify-between items-start pb-4 border-b">
                        <div>
                          <span className="text-sm font-black text-slate-900 dark:text-white block">HELIOSGUARD SOLUTIONS CO.</span>
                          <span className="text-[9px] font-mono font-bold tracking-widest text-slate-450 uppercase">OFF-GRID SOLAR & Surveillance INTELLIGENCE</span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-bold text-slate-400 bg-slate-50 dark:bg-slate-800 px-2 py-1 rounded">Invoice: {latestGeneratedOrder.id}</span>
                          <p className="text-[10px] mt-1 text-slate-400 font-mono">{new Date(latestGeneratedOrder.createdAt).toLocaleDateString()}</p>
                        </div>
                      </div>

                      {/* Details of Buyer */}
                      <div className="grid grid-cols-2 gap-4 text-xs">
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">Deliver Site buyer:</span>
                          <span className="font-extrabold text-slate-900 dark:text-white text-sm block">{latestGeneratedOrder.customerName}</span>
                          <span className="block mt-0.5">{latestGeneratedOrder.customerEmail} • {latestGeneratedOrder.customerPhone}</span>
                          <span className="block italic text-[11px] mt-1 family-mono">Site: {latestGeneratedOrder.address}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">Assigned Engineer node:</span>
                          <span className="font-extrabold block">Vanguard high-voltage team</span>
                          <span className="block">Status: <span className="bg-blue-100 text-blue-700 font-bold uppercase rounded px-1.5 py-0.5">{latestGeneratedOrder.status}</span></span>
                        </div>
                      </div>

                      {/* Items list */}
                      <table className="w-full text-left font-semibold">
                        <thead>
                          <tr className="border-b text-slate-405 font-bold uppercase tracking-wider text-[10px]">
                            <th className="py-2">Item Sized Name</th>
                            <th className="py-2 text-center w-16">Qty</th>
                            <th className="py-2 text-right w-24">Price</th>
                            <th className="py-2 text-right w-24">Total</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {latestGeneratedOrder.items.map((i, idz) => (
                            <tr key={idz}>
                              <td className="py-2.5 font-extrabold text-slate-900 dark:text-slate-100">{i.productName}</td>
                              <td className="py-2.5 text-center font-bold">{i.quantity}</td>
                              <td className="py-2.5 text-right font-mono">₦{i.price}</td>
                              <td className="py-2.5 text-right font-mono font-bold">₦{i.price * i.quantity}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>

                      {/* Totals */}
                      <div className="pt-4 border-t flex flex-col items-end gap-1 font-extrabold">
                        <div className="flex justify-between w-64 text-slate-405">
                          <span>Sized subtotal:</span>
                          <span className="font-mono">₦{latestGeneratedOrder.totalPrice}</span>
                        </div>
                        <div className="flex justify-between w-64 text-slate-405">
                          <span>Dispatch Courier:</span>
                          <span className="font-semibold uppercase text-[10px]">Site Sized Free</span>
                        </div>
                        <div className="flex justify-between w-64 text-lg font-black text-slate-900 dark:text-white pt-2 border-t mt-1">
                          <span>GRAND TOTAL DUE:</span>
                          <span className="text-blue-600 dark:text-blue-400 font-mono">₦{latestGeneratedOrder.totalPrice.toLocaleString()}</span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-slate-100 text-xs">
                        <button 
                          onClick={() => handleTriggerWhatsAppOrder(latestGeneratedOrder)}
                          className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-center transition flex justify-center items-center gap-1.5"
                        >
                          <PhoneCall className="w-4 h-4" />
                          <span>Dispatch via WhatsApp checkout</span>
                        </button>
                        
                        <button 
                          onClick={() => window.print()}
                          className="px-6 py-3 bg-slate-90 w-full sm:w-auto bg-slate-900 border text-white font-mono rounded-xl hover:bg-slate-800 text-center"
                        >
                          Print Invoice
                        </button>

                        <button 
                          type="button"
                          onClick={() => { setCheckoutStep('cart'); setActiveTab('home'); }}
                          className="px-6 py-3 bg-slate-100 text-slate-850 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-350 dark:hover:bg-slate-700 rounded-xl text-center"
                        >
                          Return Home
                        </button>
                      </div>

                    </div>
                  )}

                </div>

                {/* Right Summary sidebar panel ONLY present in non-invoice checkout phases */}
                {checkoutStep !== 'invoice' && (
                  <div className="lg:col-span-4 bg-slate-50 dark:bg-slate-900 border rounded-3xl p-6 self-stretch flex flex-col justify-between">
                    <div>
                      <h4 className="font-extrabold text-xs text-slate-850 dark:text-white mb-4 uppercase tracking-widest text-[9px] text-slate-400">Order pricing overview</h4>
                      
                      <div className="space-y-3 text-xs font-semibold">
                        <div className="flex justify-between">
                          <span className="text-slate-405">Items Count:</span>
                          <span className="font-bold text-slate-800 dark:text-slate-205">{cart.reduce((acc, c) => acc + c.quantity, 0)} units</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-450">Sized subtotal:</span>
                          <span className="font-black text-slate-850 dark:text-slate-100 font-mono">₦{cartTotal.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between pb-3 border-b">
                          <span className="text-slate-400">Tax Index (CO2 offset):</span>
                          <span className="text-emerald-600 font-bold">0% tax exempt</span>
                        </div>
                        <div className="flex justify-between text-base font-black pt-2 text-slate-900 dark:text-white">
                          <span>Grand Fee:</span>
                          <span className="text-blue-600 dark:text-blue-400 font-mono">₦{cartTotal.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-6 mt-6 border-t text-[10px] text-slate-400 text-center leading-relaxed font-medium">
                      🔒 Secured TLS transaction checkout channels. HeliosGuard utilizes standard power distribution license agreements.
                    </div>
                  </div>
                )}

              </div>
            )}

          </div>
        )}

        {/* TAB 7: WISHLIST VIEW */}
        {activeTab === 'wishlist' && (
          <div className="space-y-8" id="view-wishlist-favorites">
            <div className="border-b border-slate-100 pb-4">
              <span className="text-[10px] font-bold text-rose-500 uppercase font-mono tracking-widest">My Account</span>
              <h2 className="text-3xl font-black text-slate-805 dark:text-white">Sized Favorites / Wishlist</h2>
            </div>

            {wishlist.length === 0 ? (
              <div className="text-center py-16 bg-white dark:bg-slate-900 rounded-3xl border text-slate-400">
                <Heart className="w-12 h-12 text-slate-200 mx-auto mb-3" />
                <h3 className="text-sm font-semibold">No favorites stored inside current frame</h3>
                <p className="text-xs text-slate-405 mt-1">Browse our catalogs and hit the standard heart icons to track components.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {wishlist.map((p) => (
                  <div key={p.id} className="bg-white dark:bg-slate-900 rounded-2xl p-4 border flex flex-col justify-between shadow-xs">
                    <div>
                      <img src={p.imageUrl} alt={p.name} className="w-full h-36 object-cover rounded-xl border mb-3" />
                      <span className="text-[9px] uppercase font-bold text-slate-400">{p.brand}</span>
                      <h4 className="font-extrabold text-xs text-slate-800 dark:text-white line-clamp-2 h-8 mt-1">{p.name}</h4>
                      <p className="text-sm font-black font-mono text-blue-600 dark:text-blue-400 mt-2">₦{p.price}</p>
                    </div>

                    <div className="flex gap-2 pt-3 mt-4 border-t text-xs font-semibold">
                      <button 
                        onClick={() => handleToggleWishlist(p)}
                        className="p-2 border text-slate-400 hover:text-rose-500 rounded-lg"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => { handleAddToCart(p); handleToggleWishlist(p); }}
                        className="flex-1 py-1.5 bg-blue-600 text-white font-bold rounded-lg text-center"
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 8: ADMIN DASHBOARD PANEL */}
        {activeTab === 'admin' && (
          <div className="animate-fadeIn" id="view-admin-dashboard">
            <AdminPanel
              products={products}
              orders={orders}
              quotes={quotes}
              analytics={analytics}
              onAddProduct={handleAddProductAdmin}
              onEditProduct={handleEditProductAdmin}
              onDeleteProduct={handleDeleteProductAdmin}
              onChangeOrderStatus={handleChangeOrderStatusAdmin}
              onChangeQuoteStatus={handleChangeQuoteStatusAdmin}
            />
          </div>
        )}

      </main>

      {/* FLOATING COLLAPSIBLE AI ADVISOR MESSENGER PANEL (Fixed on bottom right) */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end" id="floating-ai-messenger">
        <div className="relative group">
          {/* Main Round Badge launcher Button toggle */}
          <button
            onClick={() => {
              // swap or toggle modal chat
              const chatBox = document.getElementById('ai-advisor-panel-box');
              if (chatBox) {
                chatBox.classList.toggle('hidden');
              }
            }}
            className="w-14 h-14 bg-gradient-to-br from-blue-600 to-indigo-700 hover:scale-105 active:scale-95 text-white rounded-full flex items-center justify-center shadow-xl cursor-pointer transition"
            title="HeliosGuard Interactive AI Sizing Advisory"
            id="ai-messenger-icon-trigger"
          >
            <Sparkles className="w-6 h-6 animate-pulse" />
          </button>
        </div>

        {/* Floating Chat Container Box (hidden by default) */}
        <div 
          className="hidden w-80 sm:w-96 bg-white dark:bg-slate-900 border border-slate-205 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden mt-3 flex flex-col text-xs max-h-[460px] animate-fadeIn transition-colors duration-300"
          id="ai-advisor-panel-box"
        >
          {/* Box Header */}
          <div className="px-4 py-3 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex justify-between items-center bg-slate-900">
            <div className="flex items-center gap-1.5 font-bold">
              <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></div>
              <span>HeliosGuard AI Advisory Desk</span>
            </div>
            <button 
              onClick={() => {
                const chatBox = document.getElementById('ai-advisor-panel-box');
                if (chatBox) chatBox.classList.add('hidden');
              }}
              className="p-1 hover:bg-white/10 rounded text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Active messages timeline */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-72">
            {aiReplies.map((reply, index) => {
              const isAss = reply.role === 'assistant';
              return (
                <div key={index} className={`flex ${isAss ? 'justify-start' : 'justify-end'}`}>
                  <div className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${isAss ? 'bg-slate-50 dark:bg-slate-800 border dark:border-slate-700 text-slate-800 dark:text-slate-250 font-medium' : 'bg-blue-600 text-white font-semibold'}`}>
                    {reply.text}
                  </div>
                </div>
              );
            })}
            
            {isAiLoading && (
              <div className="flex justify-start">
                <div className="p-3 bg-slate-50 dark:bg-slate-800 border dark:border-slate-705 rounded-2xl text-slate-400 flex items-center gap-1.5 italic">
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
                  Analyzing storage telemetry sizing...
                </div>
              </div>
            )}
          </div>

          {/* Input field */}
          <form onSubmit={handleSendAiQuestion} className="p-3 border-t bg-slate-50/50 dark:bg-slate-950/40 flex gap-2">
            <input 
              type="text"
              required
              placeholder="e.g. recommend battery for a 200W load"
              value={aiQuestion}
              onChange={(e) => setAiQuestion(e.target.value)}
              className="flex-1 p-2 border rounded-xl bg-white dark:bg-slate-800 text-slate-800 dark:text-white focus:outline-none text-xs"
            />
            <button 
              type="submit" 
              className="p-2 bg-blue-650 bg-blue-600 font-bold hover:bg-blue-700 text-white rounded-xl"
              title="Query AI advisor"
            >
              Send
            </button>
          </form>
        </div>
      </div>

      {/* DYNAMIC PRODUCT DETAILS SPECS MODAL OVERLAY */}
      {activeProductModal && (
        <ProductDetailsModal
          product={activeProductModal}
          onClose={() => setActiveProductModal(null)}
          onAddToCart={handleAddToCart}
          onAddReview={handleAddReview}
          wishlist={wishlist}
          onToggleWishlist={handleToggleWishlist}
        />
      )}

      {/* Global integrated footer element */}
      <Footer />

    </div>
  );
}
