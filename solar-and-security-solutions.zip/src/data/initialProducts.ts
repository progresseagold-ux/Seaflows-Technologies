import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  // SOLAR PRODUCTS
  {
    id: "sol-mono-550w",
    name: "Aura 550W Mono-PERC Bifacial Solar Panel",
    category: "solar",
    subCategory: "panels",
    brand: "Aura Solar",
    price: 249,
    imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Max Power (Pmax)": "550W",
      "Open Circuit Voltage (Voc)": "49.8V",
      "Short Circuit Current (Isc)": "14.01A",
      "Module Efficiency": "21.3%",
      "Cell Type": "Monocrystalline PERC (Bifacial)",
      "Dimensions": "2278 x 1134 x 35 mm",
      "Weight": "28.6 kg"
    },
    description: "The Aura 550W Mono-PERC Bifacial solar panel features dual-glass generation technology, capturing light from both front and rear sides to bolster energy capture by up to 25% depending on surface albedo. Ideal for clean corporate or residential utility scale setups.",
    installationDetails: "Heavy-duty mounting system recommended. Double-insulated 4mm² solar cables required. Mount at optimum tilt angle facing true North (Southern Hemisphere) or true South (Northern Hemisphere).",
    warranty: "25-year linear performance warranty, 12-year product material warranty.",
    stock: 45,
    rating: 4.8,
    reviews: [
      { id: "rev1", user: "Alexander Mercer", rating: 5, comment: "Incredible energy yield even in diffuse morning light. The build quality with dual-glass is outstanding.", date: "2026-04-12" },
      { id: "rev2", user: "Sophia Vance", rating: 4, comment: "Excellent performance, heavier than expected due to dual glass so make sure structural rails are sturdy.", date: "2026-05-18" }
    ],
    featured: true
  },
  {
    id: "sol-inv-hybrid-8kw",
    name: "Sunsynk 8kW Single-Phase Hybrid Smart Inverter",
    category: "solar",
    subCategory: "inverters",
    brand: "Sunsynk",
    price: 1899,
    imageUrl: "https://images.unsplash.com/photo-1620021618092-6f73d63bd9c8?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Nominal AC Output": "8000W",
      "Max DC Input Power": "10400W",
      "MPPT Tracker Number": "2",
      "Battery Bank Voltage": "48V Nominal",
      "Max Charging/Discharging Current": "190A",
      "Efficiency": "97.6%",
      "IP Rating": "IP65 weatherproof"
    },
    description: "The Sunsynk 8kW Hybrid Inverter is a highly efficient power management tool that manages power flow from multiple sources: solar, main grid, battery storage, and even generator backup. Features a touch screen LCD and robust web-app tracking.",
    installationDetails: "Wall-mount indoors or in shaded outdoor enclosure. Requires single-phase mains integration. Must be installed by an authorized grid-tie installer.",
    warranty: "5-year standard warranty, extendable up to 10 years upon product registry.",
    stock: 12,
    rating: 4.9,
    reviews: [
      { id: "rev3", user: "David Thorne", rating: 5, comment: "The touch control screen and custom power settings for grid peak-shaving work perfectly. My favorite inverter hands down.", date: "2026-03-01" }
    ],
    featured: true
  },
  {
    id: "sol-bat-lifepo4-5kwh",
    name: "VoltGuard Pro 5.12kWh LiFePO4 Lithium Battery",
    category: "solar",
    subCategory: "batteries",
    brand: "VoltGuard",
    price: 1450,
    imageUrl: "https://images.unsplash.com/photo-1548345680-f5475ea5df84?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Battery Type": "Lithium Iron Phosphate (LiFePO4)",
      "Nominal Energy": "5.12 kWh",
      "Nominal Voltage": "51.2V",
      "Usable Capacity": "4.86 kWh (95% DoD)",
      "Max Charge/Discharge": "100A / 100A",
      "Cycle Life": ">= 6000 cycles at 80% DoD",
      "Weight": "44 kg"
    },
    description: "The VoltGuard Pro is a premium modular storage unit designed to pair with 48V hybrid inverters. Standard rackmount frame, supports seamless parallel scaling up to 16 units for extensive home back-up or commercial sites.",
    installationDetails: "Standard cabinet shelf or flat secure wall mount bracket. Connect with high-grade 35mm² DC lugs with pre-charging battery safety fuses.",
    warranty: "10-year mechanical and output warranty.",
    stock: 22,
    rating: 4.7,
    reviews: [
      { id: "rev4", user: "Liam Hayes", rating: 5, comment: "Clean look, neat CAN bus communication with my Synk inverter. Runs my fridge, ACs, and server rack all night effortlessly.", date: "2026-05-10" }
    ],
    featured: true
  },
  {
    id: "sol-ctrl-mppt-100",
    name: "Victron SmartSolar MPPT 150/70 Auto-Charger",
    category: "solar",
    subCategory: "charge_controllers",
    brand: "Victron Energy",
    price: 389,
    imageUrl: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Max Solar Voltage (Voc)": "150V",
      "Rated Charge Current": "70A",
      "Battery Voltage Auto-Sync": "12V / 24V / 36V / 48V",
      "Max PV Power (48V stack)": "4000W",
      "Conversion Efficiency": "98%",
      "Communication": "Bluetooth Smart Built-in"
    },
    description: "Ultra-fast Maximum Power Point Tracking (MPPT) solar charge builder. Especially in case of a clouded sky, when light intensity is changing continuously, an ultra-fast MPPT controller will improve energy harvest by up to 30%.",
    installationDetails: "Mount vertically on non-combustible surface. Check fuse ratings before hooking up to battery arrays.",
    warranty: "5-year worldwide limited product warranty.",
    stock: 30,
    rating: 4.9,
    reviews: [],
    featured: false
  },
  {
    id: "sol-cable-100m",
    name: "UltraFlex 6mm² Double Insulated Solar Cable (100m)",
    category: "solar",
    subCategory: "accessories",
    brand: "UltraFlex",
    price: 110,
    imageUrl: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Conductor Size": "6 mm²",
      "Length": "100 meters spool",
      "Voltage Rating": "1500V DC",
      "Conductor Material": "Tinned Copper (Class 5)",
      "Insulation/Sheath": "Halogen-free XLPE / Copolymer",
      "UV & Weatherproof": "Yes, EN 50618 compliant"
    },
    description: "Professional UV-resistant solar cables engineered to connect solar arrays to inverters and chargers, safeguarding your system from harsh environmental degradation.",
    installationDetails: "Ensure MC4 crimps are secured. Tie onto framing rails with solar-rated UV locks.",
    warranty: "15-year environmental rating warranty.",
    stock: 120,
    rating: 4.6,
    reviews: [],
    featured: false
  },

  // CCTV PRODUCTS
  {
    id: "sec-cam-4k-dome",
    name: "SecuriEye 4K AcuSense Dome IP Security Camera",
    category: "cctv",
    subCategory: "cameras",
    brand: "SecuriEye",
    price: 149,
    imageUrl: "https://images.unsplash.com/photo-1557597774-9d273605dfa9?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Sensor Resolution": "8 Megapixels (3840 x 2160) at 20fps",
      "Night Vision Range": "Up to 40 meters (EXIR IR led)",
      "Lens": "2.8mm fixed focal length (107° horizontal field)",
      "Audio": "Built-in dual-mic, two-way feedback",
      "Resistance": "IP67 weatherproof, IK10 vandal-proof",
      "Power": "Power Over Ethernet (PoE) 802.3af"
    },
    description: "Equipped with AcuSense computer vision algorithms, this vandal-proof dome camera categorizes objects as human or vehicle targets, filtering out 99% of false alerts caused by foliage, downpours, or roaming wildlife.",
    installationDetails: "Mount on ceilings or outdoor walls using heavy duty junction boxes. Power via PoE-compatible switch or NVR.",
    warranty: "3-year warranty with direct advanced replacement service.",
    stock: 55,
    rating: 4.7,
    reviews: [
      { id: "rev5", user: "Gabriel Stone", rating: 5, comment: "The human detection works flawlessly. Immediate phone alerts only when actual footsteps are near the patio. 4K stream is crystal clear.", date: "2026-05-02" }
    ],
    featured: true
  },
  {
    id: "sec-cam-solar-wireless",
    name: "EagleEye Solar-Powered 4G Wireless PTZ Camera",
    category: "cctv",
    subCategory: "cameras",
    brand: "EagleEye",
    price: 320,
    imageUrl: "https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Power Supply": "Integrated 7W Solar Panel & 15,000mAh Battery",
      "Connectivity": "4G LTE Cellular Sim / 2.4GHz Wi-Fi dual-mode",
      "PTZ Control": "Pan 355°, Tilt 120°, 4X Digital Zoom",
      "Sensor & LED": "4MP 2K Video, Full-Color Night Vision",
      "Storage": "MicroSD slot support up to 256GB / Cloud storage"
    },
    description: "A completely wire-free, self-sufficient security camera, perfect for remote farms, construction spaces, field installations, and off-grid zones. Packs high-sensitivity motion triggering and two-way voice communication.",
    installationDetails: "Ensure the mounting site receives at least 4 hours of direct solar exposure daily. SIM card must be pre-activated with a steady data bundle.",
    warranty: "2-year product warranty.",
    stock: 18,
    rating: 4.5,
    reviews: [
      { id: "rev6", user: "Carlos Rivera", rating: 4, comment: "Great for active construction sites where we have no Wi-Fi or mains. Kept active through the whole rainy season.", date: "2026-04-20" }
    ],
    featured: true
  },
  {
    id: "sec-nvr-8ch-poe",
    name: "ProGuard 8-Channel 4K Intelligent PoE NVR",
    category: "cctv",
    subCategory: "dvrs",
    brand: "ProGuard Security",
    price: 299,
    imageUrl: "https://images.unsplash.com/photo-1563770660941-20978e870e26?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Video Input": "8-Channel PoE IP Cameras",
      "Output Interface": "1x HDMI (up to 4K resolution), 1x VGA",
      "Compression Standard": "H.265+ / H.265 / H.264",
      "SATA Capability": "2x SATA Interfaces (Up to 10TB per HDD)",
      "Bandwidth Capacity": "80 Mbps Inbound / 160 Mbps Outbound"
    },
    description: "The ProGuard 8-Channel NVR is an enterprise-grade surveillance processor supporting live viewing, synched video playback, and scheduled backups. Its plug-and-play PoE design auto-detects security feeds directly.",
    installationDetails: "Connect to standard mains power outlet. Link with router via Ethernet to gain remote viewing on mobile devices.",
    warranty: "3-year standard manufacturer warranty.",
    stock: 15,
    rating: 4.8,
    reviews: [],
    featured: true
  },
  {
    id: "sec-hdd-purple-4tb",
    name: "WD Purple 4TB Surveillance 3.5\" Internal HDD",
    category: "cctv",
    subCategory: "accessories",
    brand: "Western Digital",
    price: 125,
    imageUrl: "https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=600&auto=format&fit=crop&q=80",
    specs: {
      "Capacity": "4 Terabytes",
      "Form Factor": "3.5 Inches",
      "Interface": "SATA 6 Gb/s",
      "Workload Rating": "Up to 180 TB/year",
      "Buffer Size": "64 MB Cache",
      "Optimized for": "Continuous 24/7 Surveillance Recording"
    },
    description: "Built for high-definition 24/7 security recording. WD Purple surveillance storage feature Western Digital's exclusive AllFrame technology, allowing you to confidently build a custom home or business security recording bank.",
    installationDetails: "Slips inside NVR drawer. Fasten with standard side screws. Secure data/power SATA link flatly.",
    warranty: "3-year manufacturer limited warranty.",
    stock: 60,
    rating: 4.7,
    reviews: [],
    featured: false
  }
];
